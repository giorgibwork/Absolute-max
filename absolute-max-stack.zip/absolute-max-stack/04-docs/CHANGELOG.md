# Changelog

## 2026-10-29 — v1.0 Absolute Max Stack
- Orchestrator: absolute-max (Eye of God + ADHD + Hyperresearch + STAIR + MRIP)
- 18 late-2026 research modules embedded in arkon-hyperresearch and hyperresearch
- Structure-aware retrieval (STAIR) skill
- Portable transfer kits (full + 8k GPT version)
- Continuous improvement protocol and living patch log
