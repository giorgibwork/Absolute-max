# Continuous Large-Margin Improvement Protocol

This stack is designed to improve itself with big margins, not incremental tweaks.

## Rules
1. Every full research or optimization run ends with a self-evolution hook (PAPER2LLM++ style).
2. Process failure modes are extracted and written to `05-improvement/FUTURE-PATCHES.md`.
3. Only patches that raise at least one of the six MRIP axes by ≥1 point (or add a new compounding capability) are accepted.
4. After three accepted patches, update the CURRENT-BASELINE and bump the version.
5. Plateau is forbidden. If three consecutive runs show ≤0.5 average axis improvement, force a deeper decomposition or new evaluation criterion.

## How to propose a patch
In FUTURE-PATCHES.md use this format:

### [Date] — Short title
- Observed failure / opportunity
- Proposed change (exact skill file + section)
- Expected axis lift
- Evidence or reasoning
- Status: proposed / accepted / rejected / implemented

## Priority order for future gains
1. Stronger formal verification & Lean integration
2. Better multi-agent density + cross-link quality
3. Tighter effort-vs-value controller
4. Native Arkon Vault MCP integration improvements
5. Automatic skill-patch generation from self-evolution logs
