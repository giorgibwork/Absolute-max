# How to Implement the Absolute Max Stack

## 1. Choose your platform
- Custom GPT → use GPT-8K-INSTRUCTIONS.md
- Claude Projects / Gemini Gems / Grok → use PASTE-ME-MASTER.md or modular load
- Local models → system prompt + optional RAG over the skill files

## 2. Load order (critical)
1. absolute-max.md (orchestrator)
2. MRIP_v3.md (state + scoring contract)
3. Any specialized skills needed for the task (hyperresearch, structure-aware-retrieval, etc.)

## 3. Activation
Trigger phrases: “absolute max”, “maximize this”, “eye of god”, “hyperresearch”, “STAIR”, “structure-aware”, or any high-ambition request.

## 4. Expected behavior
- ADHD action-first shape (until user says “stop adhd mode”)
- Full MRIP five-block ending on every response
- Structure-aware retrieval on hierarchical documents
- 18 late-2026 research modules active on deep research runs
- Permanent compounding assets left after every turn

## 5. Multi-AI continuity
Use Arkon Vault (or equivalent) handoffs so work continues across different AIs without loss of state.
