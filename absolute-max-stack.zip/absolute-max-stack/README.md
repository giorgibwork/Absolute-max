# Absolute Max Stack — Complete Portable System

Version: 2026-10-29  
Purpose: Highest-leverage AI operating system for research, optimization, and recursive self-improvement. Designed for continuous large-margin improvement.

## Folder Structure

```
absolute-max-stack/
├── 01-core/                  # Always load first
│   ├── absolute-max.md       # The orchestrator
│   └── MRIP_v3.md            # Recursive improvement protocol
├── 02-skills/                # Specialized modules
│   ├── arkon-hyperresearch.md
│   ├── hyperresearch.md
│   ├── structure-aware-retrieval.md
│   ├── eye-of-god.md
│   ├── i-have-adhd.md
│   └── structure-aware-retrieval-assets/
├── 03-transfer/              # Ready-to-paste versions
│   ├── GPT-8K-INSTRUCTIONS.md   # For Custom GPTs (under 8k chars)
│   ├── PASTE-ME-MASTER.md       # Full power for Claude/Gemini/Grok/local
│   └── TRANSFER-README.md
├── 04-docs/                  # How to use and extend
│   ├── HOW-TO-IMPLEMENT.md
│   ├── IMPROVEMENT-PROTOCOL.md
│   └── CHANGELOG.md
└── 05-improvement/           # Living improvement log + future patches
    ├── CURRENT-BASELINE.md
    └── FUTURE-PATCHES.md
```

## Quick Start

### On Grok / this environment
The skills are already live in `/home/workdir/.grok/skills/`. Just activate with “absolute max”, “hyperresearch”, “STAIR”, etc.

### On Custom GPTs (ChatGPT)
1. Open Configure → Instructions
2. Paste the entire contents of `03-transfer/GPT-8K-INSTRUCTIONS.md`
3. Save

### On Claude / Gemini / other long-context AIs
Paste `03-transfer/PASTE-ME-MASTER.md` (or load absolute-max.md + MRIP_v3.md + desired skills).

### On local / open models
Concatenate the core files into the system prompt. Keep specialized skills as optional context.

## Continuous Improvement Rule
Every full research or optimization run must leave at least one compounding asset and, when process failures are discovered, a proposed patch in `05-improvement/FUTURE-PATCHES.md`.  
MRIP forbids plateau. Big-margin gains come from systematically raising the evaluation bar, not from one-off tweaks.
