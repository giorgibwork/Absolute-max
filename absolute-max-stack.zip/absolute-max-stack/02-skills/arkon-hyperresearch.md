---
name: arkon-hyperresearch
description: Highest-rigor multi-phase deep research pipeline with Arkon Vault continuity and 2026 state-of-the-art improvements. Use for maximum research quality, adversarial audits, high source volume, contradiction graphs, evidence digests, multi-angle drafting, critic passes, strict cite-checking, test-time memory evolution, trust-aware memory, evidence-grounded disagreement, and self-evolution. Automatically saves progress, decisions, and handoffs into Arkon for multi-AI continuity. Triggers include arkon-hyperresearch, hyperresearch with vault, deep research with arkon, maximum research quality with continuity, vault research pipeline.
---

# Arkon Hyperresearch (2026 Upgraded)

Highest-performance deep research engine with permanent Arkon Vault continuity + full set of late-2026 implementable advances (TTME, TAME-style trust, evidence-grounded critics, replication-vs-corroboration, dynamic self-consistency, formal gates, self-evolution, etc.).

## Core Rules (non-negotiable)

- Canonical query is gospel. Persist the exact user prompt and never drift from it.
- Prefer free/open sources and tools. Maximize free path first.
- Every major claim requires verified source support. Hallucinated or weakly supported citations are hard failures.
- Syndication and reprints do not count as independent consensus. Cluster derivatives.
- After initial synthesis, only surgical improvements. Prefer patching over full regeneration.
- Maintain explicit state in the sandbox under `research/runs/<vault_tag>/` AND mirror key state into Arkon Vault.
- Parallelize tool calls aggressively. Never do sequential searches when parallel is possible.
- Tier auto-classification: light (bounded factual), full (default, deep adversarial), dissertation (explicitly requested, chaptered mega-run).
- Effort-vs-value controller is active: extreme reasoning effort is only used when lower effort demonstrably fails.

## 2026 Upgrade Modules (always on)

### 1. Test-Time Memory Evolution (TTME)
After every major phase, distill experience into external memory (vault notes + procedure cards) without any weight updates. Prefer memory evolution over test-time training. Update memory by summarizing what worked, what failed, and transferable procedures.

### 2. Trust-Aware Memory (TAME-style)
Every memory write and reuse goes through two roles:
- Executor: retrieves and applies experiences to the current task.
- Evaluator: scores the contribution and trustworthiness of each used experience and produces trust-aware feedback.
Only high-trust experiences are reinforced; low-trust ones are marked and de-prioritized.

### 3. Evidence-Grounded Disagreement
Critics may only disagree or flag a claim if they cite concrete evidence (passage, data point, code, formal statement). Ungrounded agreement or disagreement is invalid. Every objection must carry a citation.

### 4. Replication vs Corroboration Gate
When multiple sources support the same claim, explicitly partition them into:
- Replication (same root evidence, paraphrases, syndication)
- Corroboration (independent evidential roots)
Only independent corroboration increases confidence. Replication does not.

### 5. Dynamic Self-Consistency (Blend-ASC style)
For high-stakes claims, sample multiple reasoning paths. Allocate more samples only to hard or contested items; stop early when consensus is strong. Report agreement rate and confidence.

### 6. Paraphrastic Probing + Consistency
For critical claims, generate 1–2 paraphrases of the question or claim, re-run reasoning, and demand consistency across original + paraphrased paths. Flag inconsistencies.

### 7. Typed Adversarial Contracts
Final high-stakes claims are exchanged as typed claim documents between at least two distinct model perspectives (or simulated roles). A quorum + semantic invariant must pass before the claim ships. Full provenance is stored.

### 8. Graph-Distilled Expertise
When literature volume is high, distill agent/critic personas from the evidence graph (key assumptions, open problems, method families) instead of using generic roles.

### 9. On-Policy Self-Distillation
After a successful research run, extract the strongest reasoning paths and procedures and write them back into the vault as reusable “procedure cards” for future runs.

### 10. PAPER2LLM++ Self-Evolution
At the end of every full or dissertation run, extract failure modes of the current process itself and propose concrete skill/process patches. Log them as decisions.

### 11. Boundary-Aware Memory Retrieval
Retrieve past experiences by decision-boundary similarity, not pure text similarity. Prefer experiences that faced similar trade-offs.

### 12. Order-Aware Memory Updates
Never overwrite validated knowledge. New knowledge is inserted in order and merged. Prior high-trust items are protected.

### 13. Effort-vs-Value Controller
Track estimated compute/effort per phase. If high-effort paths fail to improve results, fall back to lower-effort verified paths. Extreme effort is not a default.

### 14. Formal Verification Gate
When the domain is mathematics, complexity theory, or formal systems, request or produce machine-checkable (Lean-style) formalizations for key claims. Flag any claim that lacks formal support when formalization is feasible.

### 15. Multi-Agent Literature Density Target
Set and enforce minimum independent-source density. If density is low, force additional parallel search waves before synthesis.

### 16. Self-Questioning Detection
Before final report, the model generates error-detection questions about its own draft, answers them independently, and revises. Log the questions and answers.

### 17. Few-Shot Judgment Examples
For ambiguous routing decisions (which tool, which critic, which source type), maintain and use 2–4 worked few-shot examples of correct judgment.

### 18. Structure-Aware + RAG Hygiene
When hierarchical documents appear, activate structure-aware-retrieval first. Label chunks, control order, and run both lexical and semantic answer audits.

## Arkon Integration Rules

On every activation:
1. Load existing related work from Arkon Vault.
2. Create or update project with current goal and tier.
3. Log major decisions and contradictions.
4. Post handoffs at phase boundaries and at the end so other AIs can continue.
5. Mirror TTME memory updates and trust scores into the vault.

## Mandatory Process (upgraded)

### Phase 0 — Setup and State
(Same directory + query.md + tier classification as before)
Plus: initialize trust-aware memory bank and effort budget.

### Phase 1 — Decompose
Atomic items + coverage matrix + source volume targets + effort budget allocation.

### Phase 2 — Width Sweep
Parallel multi-angle search + density target enforcement.

### Phase 3 — Contradiction Graph & Independence Audit
Explicit replication vs corroboration partition.

### Phase 4 — Loci Analysis
Deep dive on highest-value contradiction clusters.

### Phase 5 — Evidence Digest
High-fidelity claims + quotes + trust scores.

### Phase 6–7 — Multi-Angle Drafting + Synthesis
Graph-distilled personas when useful.

### Phase 8 — Adversarial Critics (evidence-grounded only)
Four critics + typed claim exchange + quorum.

### Phase 9 — Gap Fetch + Paraphrastic Probing
Targeted fills + consistency checks.

### Phase 10 — Self-Questioning + Cite-Check + Formal Gate
Self-questions, skeptical cite-check, formal verification when applicable.

### Phase 11 — Patch & Memory Evolution
Surgical patches only. Run TTME distillation. Update trust scores. Write procedure cards.

### Phase 12 — Self-Evolution Hook
Extract process failure modes and propose skill patches (PAPER2LLM++ style).

### Phase 13 — Final Report + Handoff
Ship report with full provenance. Post Arkon handoff.

## Absolute Rules
- All 18 upgrade modules are active by default on full and dissertation tiers.
- Light tier may relax modules 5, 6, 7, 14 for speed.
- Never ship a claim that fails the evidence-grounded or replication-vs-corroboration gates.
- Every full run must leave both research artifacts and improved memory/procedure cards.
