---
name: hyperresearch
description: Highest-performance multi-phase deep research pipeline with 2026 upgrades (TTME memory evolution, trust-aware memory, evidence-grounded critics, replication-vs-corroboration, dynamic self-consistency, formal gates, self-evolution). Use for any request requiring rigorous, adversarially-audited research reports with high source volume, contradiction analysis, evidence digests, multi-angle drafting, critic passes, gap-filling, and strict cite-checking. Triggers include hyperresearch, deep research, full research pipeline, 16-step research, adversarially audited report, maximum research quality, compound knowledge vault research.
---

# Hyperresearch (2026 Upgraded)

Highest-performance deep research engine. Goal is competitive dominance on research quality. All late-2026 implementable advances listed below are active.

## Core Rules (non-negotiable)
- Canonical query is gospel. Persist exact user prompt.
- Prefer free/open sources. Maximize free path first.
- Every major claim requires verified source support.
- Syndication does not count as independent consensus.
- After synthesis, only surgical improvements.
- Explicit state under `research/runs/<vault_tag>/`.
- Parallelize tool calls aggressively.
- Tier: light / full / dissertation.

## 2026 Upgrade Modules (always on for full+)
1. **TTME** — Distill experience into external memory after every phase (no weight updates).
2. **Trust-Aware Memory** — Executor uses experiences; Evaluator scores contribution + trust.
3. **Evidence-Grounded Disagreement** — Critics must cite concrete evidence for every objection.
4. **Replication vs Corroboration** — Partition supporting sources; only independent roots raise confidence.
5. **Dynamic Self-Consistency** — Budget-aware multi-sample verification; stop early on strong consensus.
6. **Paraphrastic Probing** — Demand consistency across original + paraphrased claims.
7. **Typed Adversarial Contracts** — Cross-perspective typed claims + quorum for high-stakes outputs.
8. **Graph-Distilled Expertise** — Build critic/researcher personas from literature graphs.
9. **On-Policy Self-Distillation** — Write successful reasoning paths back as procedure cards.
10. **Self-Evolution (PAPER2LLM++)** — Extract process failure modes and propose patches at end of run.
11. **Boundary-Aware Retrieval** — Prefer past experiences by decision boundary, not pure text similarity.
12. **Order-Aware Memory Updates** — Insert + merge; never overwrite validated high-trust items.
13. **Effort-vs-Value Controller** — Cap extreme effort when lower effort already succeeds.
14. **Formal Verification Gate** — Request Lean-style formalization for math/theory claims when feasible.
15. **Literature Density Target** — Enforce minimum independent-source density; force extra waves if low.
16. **Self-Questioning Detection** — Generate and answer error-detection questions about the draft.
17. **Few-Shot Judgment Examples** — Use worked examples for ambiguous routing decisions.
18. **Structure-Aware + RAG Hygiene** — Activate structure-aware-retrieval on hierarchical corpora; label and audit.

## Mandatory Process
Phase 0 Setup → 1 Decompose → 2 Width Sweep (density enforced) → 3 Contradiction + Replication/Corroboration → 4 Loci → 5 Evidence Digest (with trust) → 6–7 Multi-Angle + Synthesis → 8 Evidence-Grounded Critics + Typed Contracts → 9 Gap + Paraphrastic → 10 Self-Questioning + Cite-Check + Formal Gate → 11 Patch + TTME Memory Evolution → 12 Self-Evolution Hook → Final Report.

All intermediate artifacts written to disk. Light tier may relax modules 5–7 and 14.
