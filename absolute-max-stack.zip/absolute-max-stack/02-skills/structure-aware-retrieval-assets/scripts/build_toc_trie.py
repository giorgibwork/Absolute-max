#!/usr/bin/env python3
"""Minimal trie builder for STAIR-style constrained decoding.
Input: list of valid leaf section titles (one per line or JSON list).
Output: prefix tree that can be used by constrained generators.
"""
from __future__ import annotations
import json
import sys
from pathlib import Path

class TrieNode:
    def __init__(self):
        self.children: dict[str, TrieNode] = {}
        self.is_end = False

def build_trie(titles: list[str]) -> TrieNode:
    root = TrieNode()
    for title in titles:
        node = root
        for char in title:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]
        node.is_end = True
    return root

def is_valid_prefix(root: TrieNode, prefix: str) -> bool:
    node = root
    for char in prefix:
        if char not in node.children:
            return False
        node = node.children[char]
    return True

def is_complete(root: TrieNode, title: str) -> bool:
    node = root
    for char in title:
        if char not in node.children:
            return False
        node = node.children[char]
    return node.is_end

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: build_toc_trie.py titles.txt|titles.json")
        sys.exit(1)
    path = Path(sys.argv[1])
    if path.suffix == ".json":
        titles = json.loads(path.read_text())
    else:
        titles = [line.strip() for line in path.read_text().splitlines() if line.strip()]
    root = build_trie(titles)
    print(f"Built trie over {len(titles)} titles. Ready for constrained decoding.")
