# STAIR Paper Digest (arXiv:2609.03874)

## Core Claims
- Length-based chunking destroys semantic global structure.
- Giving an LLM the full ToC + query and training it to emit a real leaf title produces a generative index with near-zero structural hallucination.
- On SearchTome (18 books, 6 domains): STAIR R@1 = 82.6%, DSI = 76.9%, DPR = 68.7%, BM25 = 59.5%, raw Mistral = 13.8%. Difference vs DSI is statistically significant.
- Hallucination (non-leaf / invented titles) < 0.05% when ToC is supplied; often driven to 0.00% with trie constraint.
- ToC also improves generalization in low-data regimes.

## Architecture
1. Extract hierarchical ToC + leaf → text mapping.
2. Two training tasks:
   - Ingestion: passage → leaf title
   - Retrieval: (ToC, query) → leaf title
3. At inference: constrained decoding over valid leaf titles only.
4. Output is the section title; expand to full text for the generator if needed.

## SearchTome Construction Notes
- Source: open textbooks across Education, Finance, Law, Medicine, Natural Sciences, Social Sciences (3 books each).
- Parse PDF → extract ToC with pymupdf-style tools.
- Generate 2+ questions per eligible paragraph with Mixtral-class teacher.
- Split roughly 55/33/12 test/train/dev per book.
- Gold label = exact leaf title that contains the answer.

## Practical Maximization Levers
- Always enforce trie / constrained decoding. Soft prompting alone is insufficient.
- Prefer LoRA on Mistral-7B-Instruct-v0.2 or stronger; context window must fit full ToC.
- When training is unavailable, long-context in-context learning with the ToC still beats unstructured baselines.
- Hierarchical routing (chapter first, then section) for extremely large ToCs.
- Combine with hyperresearch: retrieve precise sections first, then run deep research only on those spans.

## Open Reimplementations
- mithilai/stair-toc-retrieval (GitHub) — full open reimplementation with 0.00% hallucination via trie.
- Community SearchTome subsets on Hugging Face for rapid experimentation.
