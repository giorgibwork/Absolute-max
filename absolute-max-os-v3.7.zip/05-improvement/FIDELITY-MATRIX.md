# Fidelity Matrix — Absolute Max OS v3.6
**Purpose:** Every module may only claim benefits that the **runtime can actually produce**.  
Paper numbers without host support = **benefit theater** (forbidden).

Primary hosts for this OS: **Grok**, **Gemini Work / Gems**, **Claude Projects**, and **Arena.ai Agent Mode**.  
Other hosts: same matrix; mark degraded if tools missing.


## Host parity (Claude & Arena)

Claude Projects and Arena Agent Mode use the **same FULL/PARTIAL/WATCH rules** as Grok/Gemini for all modules above.
- **Claude:** FULL where project knowledge + web tools exist; T0 if web off.
- **Arena Agent Mode:** Often strongest **tool** path (search + bash + connectors). HarnessMM remains PARTIAL (plan+guards); Arkon FULL when web search is used in-trajectory. Connectors are optional T2/T3 enhancers, not a substitute for skill files.

---

## Legend

| Symbol | Meaning |
|--------|---------|
| **FULL** | Enforceable with skills + host tools as specified |
| **PARTIAL** | Core idea enforceable; paper magnitude not guaranteed |
| **WATCH** | Infrastructure / weights required — track, do not claim in skills |
| **FAIL** | Must refuse the claim or enter degraded mode |

---

## Core modules

| Module | Source | Paper / stated benefit | Grok enforceable | Gemini Work enforceable | Required runtime | Degraded mode |
|--------|--------|------------------------|------------------|-------------------------|------------------|---------------|
| **Absolute Max orchestrator** | This OS | Compose layers; free-first; implement-on-discovery | FULL | FULL | Skill files + AGENTS.md | Refuse “full OS” if skills not on disk/knowledge |
| **Eye of God** | This OS | Free-only ranking by real-world effect size | FULL | FULL | Skill file | If paid-only option is uniquely best: rank free first, then note paid gap |
| **Arkon-Hyperresearch** | This OS + modules 1–27 | Multi-phase adversarial research, hard citations | PARTIAL→FULL | PARTIAL→FULL | **T1 tools** (live search/fetch) | No live search → “parametric-only research”; no hyperresearch badge |
| **STAIR-MAX** | arXiv:2609.03874 | ToC-constrained retrieval; reduce structural hallucination | FULL | FULL | Hierarchical doc + skill | Flat doc → skip STAIR; never invent section titles |
| **HarnessMM** | arXiv:2610.32813 | Guarded decision reuse; large token cuts in harness loops | PARTIAL | PARTIAL | Multi-step tools; plan with guards | Emit EDG-style plan; cannot skip host LLM rounds the API forces |
| **EGM** | google/elephant-goldfish-model | Draft + zero-context critic before design commit | FULL | FULL | Two-pass skill protocol | Single-pass only if user waives gate |
| **Router–Worker–Watchdog** | This OS | Parallel roles; continuous coordination | PARTIAL | PARTIAL | Explicit role tags in output | Single-agent narrative if parallel tools unavailable |
| **MRIP** | This OS | Five-block state + compounding asset | FULL | FULL | Skill discipline | Always apply on substantial turns |
| **ADHD shaping** | This OS | Action-first, numbered, visible wins | FULL | FULL | Skill | Until user says stop |
| **TAME + Dependency Tether** | arXiv:2610.25123 | Withdraw memory when upstream support fails | FULL | FULL | Explicit evidence tags | Never serve withdrawn claims as proven |
| **PCM / three-valued evidence** | arXiv:2610.39109 | proven / unproven / failed | FULL | FULL | Citation discipline | Agent-own-report alone = unproven |
| **RSI checklist** | This OS | Trustworthiness before self-modify | FULL | FULL | Protocol file | Block self-mod without checklist |
| **Independent verification layers** | arXiv:2610.34577 | Critic review > gates for accuracy/cost | FULL | FULL | Second-pass critique | Prefer critic pass on high-stakes outputs |
| **ZHA attention** | arXiv:2610.42112 | Subquadratic attention; 35×–400× modeled | **WATCH** | **WATCH** | Model weights + kernels | **Never** claim ZHA speedups on Grok/Gemini |

---

## Tool capability tiers (unchanged, mandatory)

| Tier | Requirement | Research claim allowed? |
|------|-------------|-------------------------|
| T0 | Skills only | No “hyperresearch” / live multi-source |
| T1 | Live search **or** fetch (transcript) | Yes — minimum |
| T2 | T1 + shell/code | Yes + scripts |
| T3 | T2 + memory store + schedules | Full agentic loop |

---

## Forbidden claims (hard)

1. HarnessMM **87.93% token reduction** as a guaranteed Grok/Gemini result  
2. ZHA **35× / 400×** attention speedups on host models we don’t control  
3. “STAIR eliminates all hallucination” (it constrains **section** identity, not all facts)  
4. “Absolute Max active” without skill **files** or knowledge attachments  
5. “Search done” without tool transcript when T1 is claimed  
6. Citations that were not retrieved in-session (unless clearly marked parametric)  

---

## Fidelity test (run after install)

```text
[ ] List each module → FULL / PARTIAL / WATCH for THIS host
[ ] One live search or fetch transcript stored
[ ] Hierarchical doc test: STAIR returns only real ToC leaves
[ ] Design change test: EGM produces Elephant + Goldfish before implement
[ ] Multi-step test: plan includes guards; state which steps can skip re-ask
[ ] Evidence test: one claim marked proven with source; one unproven
[ ] Agent refuses ZHA speedup claims
[ ] Agent refuses hyperresearch badge at T0
```

---

## When papers exceed the host

| Situation | Correct behavior |
|-----------|------------------|
| Paper needs new weights | WATCH list only; conceptual analogy allowed |
| Paper needs harness controller we lack | PARTIAL: emulate with prompt plan+guards |
| Paper needs offline training | Document; do not fake results |
| Tool missing | Drop tier; state degraded mode in first line |

**Eye of God ranking:** prefer interventions with **FULL** fidelity on free Grok/Gemini paths over **WATCH** infrastructure fantasies.
