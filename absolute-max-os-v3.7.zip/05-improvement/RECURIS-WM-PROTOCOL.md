# Recuris-Style Experiential–Working Memory Protocol
**Status:** Prototype v1 — 2026-11-01  
**Evidence base:** arXiv:2608.24876 (Recuris)  
**Target modules:** Boundary-Aware Retrieval, Order-Aware Memory, RSPM Sleep, long-horizon hyperresearch runs

## Goal
Prevent task-state burial and skill-selection drift on long-horizon runs by maintaining an explicit, verified Working Memory that conditions retrieval from Experiential Memory. Failures are localized to one of four components and patched only after validation.

## Skill Memory Package
```
M = (E, W, ρ, C)
```
- **E** — Experiential Memory: reusable skills, procedures, distilled rules, past trajectories (high compression).
- **W** — Working Memory: current verified task state (progress, open subgoals, constraints, last successful checkpoints).
- **ρ** — Invocation policy: maps W → which skills/procedures from E to call.
- **C** — Checkers / validators: programmatic or critic gates that must agree before W advances.

## Structured Trace (every step)
```
(w_t, E_t, a_t, o_t)
```
- `w_t` : Working Memory snapshot at step t (must be machine-readable / schema-constrained)
- `E_t` : which Experiential items were retrieved / used
- `a_t` : action taken (tool call, skill invocation, write)
- `o_t` : observation / outcome (success, failure signature, evidence)

## Working Memory Schema (minimal)
```yaml
working_memory:
  goal_id: string
  verified_progress:          # only advanced when C agrees
    - {checkpoint: string, evidence: string, timestamp: ISO}
  open_subgoals: [string]
  active_constraints: [string]
  last_success_anchors: [string]   # frozen solved examples for regression check
  blame_pending: null | {component: E|W|ρ|C, signature: string}
```

## Update Rules
1. **State-grounded invocation**  
   Skill selection from E is conditioned on current `w_t`, never on full chat history alone.

2. **Verified commits only**  
   `verified_progress` advances only when checkers C + environment agree. No speculative progress writes.

3. **Four-way blame localization**  
   On failure, attribute to exactly one of: E (skill content), W (state representation), ρ (invocation policy), C (checker quality). Do not patch the whole package.

4. **Validation-gated patch**  
   Proposed patch is admitted only if:
   - It repairs the blamed cluster on the failure set, AND
   - It does not regress the frozen `last_success_anchors` (held-out regression set).

5. **Bounded recursion**  
   Meta-agent (or critic phase) produces at most one localized patch per failure cluster per sleep cycle. No unbounded self-modification of the improver itself in the same turn.

## Integration Points
- **Hyperresearch Phase 11 / 11.5 (RSPM Sleep):** After clustering failures, run blame localization → candidate patch → regression check against anchors before promoting rules.
- **MRIP State Delta:** Emit `working_memory` snapshot (or delta) in State Delta when long-horizon state is active.
- **Formal Verification Gate (module 14):** Prefer Lean/programmatic checkers for C where feasible; otherwise typed critic contracts.

## Measurement
Track before/after on long-horizon runs:
- Retry loops / failure-mode frequency
- Distance-to-goal compression per phase
- Fraction of patches that pass regression gate

Target (from paper signal): material reduction in long-horizon failure modes; skill invocation stays aligned with verified progress.
