# Patch Log (Archive Only)
**Policy (v3.4+):** Do not park new improvements here for later.

When a high-leverage improvement is found:
1. Implement it immediately into live skills + AGENTS.md + protocols
2. Bump version if the change is material
3. Record a short entry in CURRENT-BASELINE.md under “Recently implemented”
4. Optionally append a one-line historical note below

This file is a historical log, not a backlog.

---

## Historical entries (pre-policy)
- 2026-11-01 EGM Elephant-Goldfish → implemented v3.2
- 2026-11-02 Router-Worker-Watchdog + STAIR-MAX → implemented v3.3
- 2026-11-02 HarnessMM guarded decision reuse → implemented v3.4
- 2026-11-02 Live skills wired to match protocols → v3.4

---

## Proposed high-leverage candidates (2026-11-03 continuous improver run)
**Note:** Per live policy, these should be implemented on discovery rather than parked. Ranked by effect size on Specificity / Novelty / Usability / Compounding / Adversarial. Free/open only.

### 1. Dependency-Tethered Memory (Tether)
- **Source:** arXiv:2610.25123 (Oct 18/22 2026) — https://arxiv.org/abs/2610.25123
- **Why it matters:** Non-local invalidation is a structural failure mode of agent memory (accurate records, unsafe actions). Tether writes exact dependency versions at verdict time (local) and withdraws stale verdicts at read time across the whole store. On Fallout: 0.3% unsafe publications vs 62% for flat fact memory, with 37% fewer checks. Directly raises adversarial robustness and citation fidelity in TAME/Recuris/hard-citation gate.
- **Concrete implementation:** Add `derived_from` / version-tether field to memory write path in TAME-MEMORY-LOOP.md and hard-citation module of arkon-hyperresearch. On read, nullify any verdict whose transitive support is failed or superseded. Integrate with RSI checklist.
- **Axis lift:** Adversarial +2–3, Specificity +1–2, Compounding +2 (new permanent failure mode + detection).

### 2. Recursive Evidence State for Claim Verification (ProClaim)
- **Source:** arXiv:2610.40906 (Oct 29 2026) — https://arxiv.org/abs/2610.40906
- **Why it matters:** Persist structured evidence state *outside* model context for consensus claim verification. Evidence state beats pure in-context accumulation; trained/fixed judges reading the state outperform fixed-round stopping. Directly strengthens hard-citation gate, self-questioning, and formal gate in Arkon modules 1–27.
- **Concrete implementation:** Add external evidence-state object (SUPPORT/REFUTE candidates + provenance + confidence) to research pipeline Phase 10 (Cite-Check + Formal Gate). Judge reads state, not just context.
- **Axis lift:** Specificity +2, Adversarial +2, Usability +1 (executable verification step).

### 3. Shinobi MCP — Shared Task Spine + Semantic Dead-Ends Ledger
- **Source:** https://github.com/numbererikson/shinobi (active Nov 2026) — MCP server with task spine, decisions log, semantic dead-end search.
- **Why it matters:** Agents stop repeating failed approaches across sessions. Semantic check before implementing similar plan. Complements Router-Worker-Watchdog (task claims, progress) and HarnessMM (guarded reuse). One shared durable spine across devices/sessions.
- **Concrete implementation:** Add as optional external tool in EXTERNAL-TOOLS-AND-PLUGINS.md and PLUGIN-LIBRARY.md. Wire `check_dead_ends` into Worker planning step of Router-Worker-Watchdog protocol. Log dead-ends from failed tool sequences.
- **Axis lift:** Usability +2, Compounding +2 (reusable cross-session asset), Adversarial +1 (avoids known bad paths).

### 4. SpectRAG — Weighted Chunk Graphs for Structure-Aware Multi-Hop RAG
- **Source:** arXiv:2610.36991 (Oct 27 2026) — https://arxiv.org/abs/2610.36991
- **Why it matters:** Combines dense embeddings + graph-spectral coordinates from weighted chunk graph (semantic similarity, document adjacency, section hierarchy, shared entities, citation links). Improves evidence recovery for multi-hop while respecting token budget. Enhances STAIR-MAX hierarchical retrieval.
- **Concrete implementation:** Extend STAIR-MAX with optional spectral/weighted graph expansion over ToC leaves and retrieved spans. Prioritize hierarchy + entity edges.
- **Axis lift:** Specificity +1–2, Novelty +1, Usability +1 (better context for long docs).

### 5. Memory Operational Principles from 3283-Paper Survey
- **Source:** openchamber.dev/blog/agent-memory-research/ (Oct 25 2026)
- **Why it matters:** Strongest evidence: keep raw history + invest in retrieval (retrieval moves accuracy ~20 pts, write strategy 3–8); fixed schema for portability across model upgrades; bind every record to origin at write time; admission control to reduce contamination 67–70%. Aligns with and hardens TAME/Recuris.
- **Concrete implementation:** Codify as mandatory checklist in TAME-MEMORY-LOOP.md and RECURIS-WM-PROTOCOL.md: (1) raw log preserved, (2) schema for mutable facts, (3) origin binding required, (4) retrieval-first over elaborate writing.
- **Axis lift:** Compounding +3 (permanent evaluation criteria), Adversarial +1, Specificity +1.

### 6. AgenticRail Gate MCP / Trust Gate MCP (deterministic step enforcement + signed receipts)
- **Source:** Recent MCP catalogs (Nov 2026); Trust Gate is post-quantum capable.
- **Why it matters:** Policy-gated tool calls with Ed25519 (or hybrid) signed receipts. Complements HarnessMM guarded reuse and formal gates. Tamper-evident audit for multi-step tool loops.
- **Concrete implementation:** Optional connector in external tools; integrate receipt verification into Watchdog and RSI checklist.
- **Axis lift:** Adversarial +2, Usability +1 (auditable orchestration).

**Immediate high-leverage recommendation:** Implement #1 (Tether) and #5 (operational principles) into live TAME / arkon-hyperresearch skills this cycle. #3 (Shinobi) as next external tool.