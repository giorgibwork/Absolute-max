# ZHA Watchlist — Not a live skill benefit
**Paper:** Zyphra Hierarchical Attention (arXiv:2610.42112)  
**Status:** WATCH only on Grok / Gemini Work

## What it is
Tree of compressed KV summaries; query routes top-down; sparse attention with asymptotic subquadratic scaling claims. Distillation into frozen models with small trainable routers.

## Why not in live skills
Requires **model/runtime attention changes**. Grok and Gemini Work do not expose ZHA. Advertising 35×–400× speedups here is **false fidelity**.

## Allowed use inside Absolute Max
- Analogy only: hierarchy before full scan (aligns with STAIR-MAX)  
- Track host models that ship hierarchical sparse attention  
- Revisit when a free/accessible model actually implements ZHA-class attention  

## Forbidden
- “We are running ZHA”  
- Claiming paper speedups on Grok/Gemini sessions  
