# Router–Worker–Watchdog Protocol
**Integrated:** Absolute Max OS v3.3 (2026-11-02)  
**Inspiration:** DeepSeek Super-agent architecture (open design exploration) + Chinese engineering commentary  
**Purpose:** Keep research and multi-step work continuous while minimizing operator attention load.

## Roles

| Role | Context | Responsibility |
|------|---------|----------------|
| **Router** | Global state across tasks | Receives requests and events, assigns work, is the single outward voice, never executes heavy tools |
| **Worker** | Isolated per task | Runs one focused investigation or implementation with full tools; reports only to Router |
| **Watchdog** | Timer + state samples | Checks that each Worker is still making progress; surfaces stalls in plain language |

## Rules
1. One human-facing channel at a time (Router speaks).
2. Workers do not talk to the user directly.
3. Long-running work is backgrounded; Router surfaces only decisions and completed results.
4. Event intake preferred over repeated full-context re-reads.
5. Watchdog runs on a fixed cadence for any Worker open longer than a threshold (default suggestion: 10–15 minutes of active work).

## Integration with Arkon-Hyperresearch
- Multi-phase research runs as one or more Workers under a Router ticket.
- Parallel source waves = parallel Workers.
- Citation gate / critic phases can be separate Workers.
- Daily improver and external signals arrive as events to the Router.

## Minimal operating loop
1. Event or user request arrives → Router classifies and opens a Worker ticket.
2. Worker executes with isolated context and full tool access.
3. Worker reports status/result to Router.
4. Router updates global state and replies (or queues a decision for the operator).
5. Watchdog samples open tickets; if stalled, flags the ticket for review.

## External tools that help
- DeepSeek Harness (`dsh`) + `dsh-superagent-prototype` (MIT) for a concrete Router/Worker runtime
- Any agent harness that supports isolated sessions + a coordinating profile
- Local session/state store (SQLite or equivalent) for ticket persistence
