# TAME-Style Executor–Evaluator Memory Loop + Dependency Tether
**Status:** Live v3.5 — 2026-11-03  
**Evidence base:** EMNLP 2026 / arXiv:2602.03224 (TAME); arXiv:2610.25123 (Tether / Dependency-Tethered Memory)  
**Goal:** Prevent Agent Memory Misevolution **and** non-local invalidation of verdicts. Derivation is local; invalidation is not. Write dependencies when local; withdraw at read time.

## Shared Memory Bank Item Schema
```yaml
memory_item:
  id: string
  content: string | structured
  source_query_or_context: string
  usefulness_score: float          # updated by Evaluator
  trust_annotation:
    level: high | medium | low | unknown
    notes: string
  dependency_tethers: [evidence_version_ids | upstream_object_versions]  # exact versions this verdict derives from
  evidence_state: proven | unproven | failed | unsettled   # three-valued; unsettled = support failed anywhere
  origin_binding: {raw_span, schema_version, writer_session}
  last_feedback: {outcome, contribution, timestamp}
```

## Tether Rule (mandatory)
- At write time (when a verdict or fact is recorded), capture the exact upstream versions / evidence IDs it derives from. Do not rely on later co-occurrence.
- At read time, before serving a passing verdict, check the whole store: if any tethered support is recorded as failed (or has a higher version), serve the item as **unsettled** (null / re-verify required). The agent sees the same fields; only the validity flag changes.
- Never serve a stale "passing" record whose support has failed upstream. This eliminates the 62% unsafe publication rate of pure fact memory.
- When relations are stated with the verdict, dependency recovery is near-perfect (~99.8%). Isolated relation statements degrade the guarantee — prefer co-location.

## Roles
### Executor
- Filters candidates by semantic relevance + usefulness_score + evidence_state ≠ failed.
- Applies selected experiences (with trust notes and unsettled flags visible) to the current task.
- On unsettled items, forces re-verification rather than trusting memory.

### Evaluator
- After outcome is known, assesses contribution of each used memory item to success/failure.
- Produces trust-aware feedback (reinforce, decay, caution, retract).
- Updates usefulness_score, trust_annotation, and may add or tighten dependency_tethers.
- Signals outer-loop policy refinement when patterns of low contribution or trust decay appear.

## Loop
1. Query → Executor retrieves & prioritizes (Tether check first).
2. Execution with trust notes + unsettled flags in context.
3. Outcome observed.
4. Evaluator attributes contribution + updates scores / annotations / tethers.
5. Low-trust, dependency-broken, or unsettled items are demoted, retracted, or forced to re-verify.
6. Periodic Sleep (RSPM) clusters failures and may refine the retrieval/write **policy**.

## Integration
- Insert Evaluator + Tether check after every memory-using phase in hyperresearch / absolute-max long runs.
- Hard-citation path must bind origin + schema + raw span and apply Tether withdrawal before any claim is treated as proven.
- Pair with RECURIS-WM-PROTOCOL so Working Memory progress remains verified independently of experiential trust scores.
- PCM-style three-valued evidence (proven / unproven / failed) is the default for inter-agent claims; agent-own-report alone is never proven.

## Success Signal
Task performance rises or holds while trustworthiness (compliance / safety / citation integrity / zero stale-verdict publication) does not decline. Tether target: ≤1% downstream unsafe publication when dependencies are captured at write time.
