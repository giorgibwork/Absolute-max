# STAIR-MAX — Structure-Aware Retrieval (Maximal)
**Integrated:** Absolute Max OS v3.3  
**Sources:** STAIR (arXiv:2609.03874), open reimplementations, HiRAG / LeanRAG / BookRAG hierarchical patterns

## Non-negotiable contract
For any hierarchical document (books, manuals, reports, handbooks, legal codes, technical docs):
1. Extract or induce a clean Table of Contents (ToC).
2. Map every leaf title to its text span.
3. Build a trie (or equivalent constraint set) over valid leaf titles / hierarchical addresses.
4. Retrieval output must be a real section title or hierarchical address that exists in the ToC.
5. Prefer hierarchical address form: `Chapter X > Section Y > Leaf Z`.

Structural hallucination of non-existent sections is treated as a failure.

## Dual mode
| Mode | When | How |
|------|------|-----|
| **Prompt-only** | Default / no training budget | Long-context model receives full ToC + query; instructed to emit only a valid leaf; post-check against trie |
| **Trained** | When LoRA/QLoRA is available | Train on (ToC, query) → leaf and passage → leaf; decode with hard trie constraint |

## Hierarchical routing (large ToCs)
1. **Local** — retrieve the tightest leaf that answers the query  
2. **Bridge** — if multi-hop, pull sibling / parent nodes that connect evidence  
3. **Global** — only when the question requires document-level aggregation  

Inspired by HiRAG / BookRAG local–bridge–global patterns.

## Evaluation (always report when measuring)
- Recall@1 / Recall@3 / nDCG@3  
- Structural hallucination rate (target: near 0%)  
- Ablation: with-ToC vs without-ToC  

## External tools / open implementations
- `mithilai/stair-toc-retrieval` — open STAIR-style reimplementation with constrained decoding  
- `Eyna-A/STAIR-ToC-RAG` — ToC-native RAG framework  
- BookRAG / HiRAG / LeanRAG papers for hierarchical index ideas  
- PDF/DOCX ToC extractors (pymupdf-class tools, heading heuristics)

## Integration rule
Arkon-Hyperresearch on hierarchical corpora must run structure-aware retrieval first and only pass retrieved section spans into research Workers.
