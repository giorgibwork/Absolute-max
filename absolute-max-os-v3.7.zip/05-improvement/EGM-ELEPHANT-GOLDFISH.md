# EGM — Elephant-Goldfish Model (Maximal Integration)
**Source:** google/elephant-goldfish-model (Apache 2.0)  
**Integrated into Absolute Max OS:** 2026-11-01 (v3.2)  
**Status:** Mandatory design gate for any non-trivial stack change or feature

## Core Principle
Design with an **Elephant** (deep context).  
Review with a **Goldfish** (zero prior conversation).  
Human makes the final architectural trade-offs.

This prevents the four classic failure modes:
1. Silent assumption carry-over from chat history
2. Unstated requirements that only appear during coding
3. Designs that cannot stand alone
4. Documentation drift

## Roles

| Role | Context | Responsibility |
|------|---------|----------------|
| **Elephant** | Full project history, requirements, prior decisions, stack state | Explore problem space and draft the specification |
| **Goldfish** | ONLY the current draft + explicitly referenced sources. No earlier conversation. | Find missing assumptions, unclear requirements, implementation risks, self-containment failures |
| **Human / Operator** | Goals and real constraints | Resolve trade-offs, approve or reject the design before any implementation |

## Mandatory Gate Rule (Absolute Max)
Any change that is **not** a pure bugfix or one-line edit MUST pass an EGM design gate before implementation:

1. Elephant draft (or update) of the design
2. At least one full Goldfish review pass (zero-context)
3. Human/operator approval recorded
4. Approved design stored under `docs/designs/` (or stack equivalent)

Self-evolution / RSI promotion of new protocols also requires this gate.

## Workflow (Maximal)

### 1. Brainstorm (Elephant + Goldfish swarm)
- Clarify concept
- Spawn multi-lens Goldfish challenge (minimum 4 lenses: Assumptions, Failure Modes, Implementation Risk, Self-Containment)
- Produce `concepts_brief.md`

### 2. Draft (Elephant)
- Turn brief into formal design document section by section
- Pause for operator feedback after each major section when possible
- Output: `design_draft.md`

### 3. Review (Goldfish — zero context)
Fresh subagent(s) that have never seen the conversation receive ONLY:
- The design document
- Explicitly linked source material / prior approved designs

Review stages (run all):
1. Clarity & completeness
2. Unstated assumptions
3. Fit with existing code / stack
4. Implementation readiness & risk
5. Self-containment (could a new agent implement from this doc alone?)

Findings are returned; operator decides which to accept.

### 4. Resolve & Approve
- Address accepted findings
- Operator records explicit approval
- Move approved design to permanent location (`docs/designs/` or `05-improvement/approved/`)

### 5. Implement
Only after approval. Coding agents may now proceed.

### 6. Drift check (optional but recommended)
Periodic Goldfish comparison of approved design vs current code/stack state.

## Integration with Existing Absolute Max Modules

| Absolute Max component | How EGM compounds |
|------------------------|-------------------|
| Adversarial critics | Goldfish is the design-time critic (before code) |
| RSI-TRUSTWORTHINESS-CHECKLIST | EGM approval is a required input before promotion |
| TAME Evaluator | Goldfish findings feed memory trust calibration |
| Recuris WM | Design state is tracked as verified Working Memory |
| PLUGIN-LIBRARY | New plugins that change behavior require EGM gate |
| Structure-aware retrieval | Approved designs become hierarchical retrieval targets |
| MRIP | Design gate status appears in State Delta |

## Activation Phrases
- `egm` · `elephant goldfish` · `design gate` · `goldfish review` · `egm-brainstorm` · `egm-draft` · `egm-review`

When Absolute Max / maximize is active and the task involves non-trivial design or stack mutation, automatically route through EGM before implementation.

## Zero-Context Enforcement (Critical)
Goldfish reviewers MUST be started in a context that contains:
- The design document text
- Only the references the design itself cites
- Nothing from the prior brainstorming or drafting conversation

If the runtime cannot spawn a true fresh context, fall back to an explicit "Goldfish simulation" prompt that forbids use of any earlier chat and forces re-derivation from the document alone. Log that a true zero-context subagent was unavailable.

## Minimal Viable Goldfish Prompt (copy-paste)
```
You are a Goldfish reviewer. You have NEVER seen any prior conversation.
You receive ONLY the design document below and any sources it explicitly links.
Your job: find unstated assumptions, missing requirements, clarity failures,
implementation risks, and places where a new agent could not implement from this
document alone. Be adversarial. Output structured findings only.
```

## Versioning
This protocol is part of Absolute Max OS v3.2+.  
Any future change to EGM integration itself requires an EGM design gate.
