# Plugin Library (PluginRSI-style)
**Status:** Skeleton v1 — 2026-11-01  
**Evidence base:** arXiv:2609.32423v2 (PluginRSI)  
**Purpose:** Atomize high-use Absolute Max / hyperresearch mechanisms so they can be improved independently, accumulated when they win, and recomposed into harnesses.

## Library Rules
1. Each plugin is a single, testable mechanism (role, tool policy, skill fragment, memory policy, or checker).
2. Mutation changes **one** plugin while the rest of the harness stays fixed.
3. A variant is added to the library only if it beats its parent on a balanced minibatch (solved + failed cases).
4. Active harness is recomposed from the library; the new composition replaces the incumbent only if it scores higher on the full held-in set.
5. Library is stored here; winning plugins are versioned with date and measured lift.

## Initial Plugins

### P-CITATION-GATE-v1
- **Role:** Hard citation + hallucination validation before any final research report ships.
- **Contract:** Every major claim has a verified source; syndication ≠ independent consensus; no report without gate pass.
- **Location:** hyperresearch module 20 / absolute-max research path.
- **Mutation surface:** validation strictness, source-tier weighting, paraphrase-probing depth.

### P-CRITIC-v1
- **Role:** Typed adversarial contracts + evidence-grounded disagreement pass.
- **Contract:** Strongest counter-argument stated; neutralized or bounded concession with trigger.
- **Location:** hyperresearch critic phase / MRIP adversarial stress test.
- **Mutation surface:** contract types, few-shot judgment examples, failure clustering linkage.

### P-MEMORY-WRITE-v1
- **Role:** Trust-aware + formal-integrity write policy for high-trust memory / vault.
- **Contract:** Environment-derived values require gate confirmation; low-belief items decay faster; dependency-tethered retraction supported.
- **Location:** TTME / Bayesian memory / RSPM write path.
- **Mutation surface:** belief update formula, sleep-phase pruning thresholds, formal gate depth.

### P-WM-TRACKER-v1
- **Role:** Recuris-style Working Memory schema and verified-progress commits.
- **Contract:** Skill invocation conditioned on `w_t`; progress advances only when checkers agree; four-way blame localization.
- **Location:** See RECURIS-WM-PROTOCOL.md.
- **Mutation surface:** schema fields, checker strictness, regression-anchor size.

### P-EVALUATOR-v1
- **Role:** TAME-style Evaluator that scores contribution of used memory to outcome and emits trust feedback.
- **Contract:** Shared bank; Executor applies, Evaluator annotates; selective reinforce / cautious reuse.
- **Location:** See TAME-MEMORY-LOOP.md.
- **Mutation surface:** contribution metric, trust annotation schema, feedback weight.

## How to Evolve
1. Select one plugin.
2. Generate N parallel mutations on a balanced minibatch.
3. Keep only those that improve the score.
4. Recompose active harness from updated library.
5. Promote only if held-in (and ideally held-out) score rises and RSI Trustworthiness Checklist passes.

## Measurement Log
| Date | Plugin | Parent → Variant | Lift | Status |
|------|--------|------------------|------|--------|
| 2026-11-01 | (init) | — | baseline | skeleton |
