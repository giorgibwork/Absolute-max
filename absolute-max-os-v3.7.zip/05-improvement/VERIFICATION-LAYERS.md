# Verification Layers — Absolute Max OS v3.6
**Source:** Rethinking Verification in Agent Harnesses (arXiv:2610.34577)  
**Integrated as prompt-level policy for Grok / Gemini Work**

Independent **critic review** is the preferred accuracy–cost tradeoff vs heavy completion gates.

## Four layers (use in order of need)

| Layer | When | What to do on Grok/Gemini |
|-------|------|---------------------------|
| **L0 Initial instructions** | Always | AGENTS.md + skills already encode quality bars |
| **L1 Mid-turn reminders** | Long multi-step | Restate goal + constraints every N steps |
| **L2 Completion gates** | High-stakes deliverables | Checklist before “done” (fidelity + cites + asset) |
| **L3 Independent review** | Design, research reports, code patches | Second pass: Goldfish / critic with minimal prior context (pairs with EGM) |

## Default policy

- Routine answers: L0  
- Multi-step tool work: L0 + L1  
- User-facing research report / stack change: L0 + L2 + **L3**  
- Prefer L3 critic over burning tokens on repeated L2 gates  

## Anti-patterns

- Infinite self-critique loops without a decision  
- Critic that only praises (must attempt to break claims)  
- Claiming “verified” without stating which layer ran  
