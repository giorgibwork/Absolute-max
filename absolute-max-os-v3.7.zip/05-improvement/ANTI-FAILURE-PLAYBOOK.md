# Anti-Failure Playbook — Absolute Max OS v3.6
**Goal:** Pre-empt every common way the stack lies, stalls, or degrades silently.

---

## 1. Install failures

| Failure | Detection | Fix |
|---------|-----------|-----|
| Prompt-only “skills applied” | Agent cannot list skill **paths** | Reinstall files / knowledge per HOW-TO-INSTALL-SKILLS |
| Partial skill set | Fewer than 6 core skills | Copy missing `02-skills/*/SKILL.md` |
| Old version stuck | AGENTS.md version ≠ package | Reload from latest zip |
| Gemini/Grok knowledge not attached | Fresh chat forgets modules | Re-upload; short system pointer only |

## 2. Tool / research failures

| Failure | Detection | Fix |
|---------|-----------|-----|
| Fake search | No tool transcript | Force T0; refuse hyperresearch |
| Rate limit (OpenRouter 50/day) | 429 errors | Stop retries; wait reset or Method-2 credits; batch tools |
| Stale parametric “news” | Claims about “today” without search | Search or mark unproven |
| Over-tooling free models | Many single tool calls | Batch; HarnessMM-style plan; fewer rounds |

## 3. Fidelity failures

| Failure | Detection | Fix |
|---------|-----------|-----|
| Benefit theater | Paper % claimed on host that can’t run it | FIDELITY-MATRIX: PARTIAL/WATCH only |
| STAIR invents sections | Leaf not in ToC | Reject; re-extract ToC |
| Citation laundering | URL never fetched | Mark unproven or fetch |
| EGM skipped | Design changed in one pass | User waive or force Goldfish pass |
| Tether ignored | Upstream failed but claim still “proven” | Withdraw claim |

## 4. Process failures

| Failure | Detection | Fix |
|---------|-----------|-----|
| Backlog parking | Only FUTURE-PATCHES updated | Implement into skills + ship zip |
| Plateau | Same advice every turn | Escalate axes; adversarial critic |
| Scope drift | Answer ignores canonical query | Restate query; restart |
| ADHD mode ignored | Walls of text | Numbered steps; next action first |
| No compounding asset | Turn ends with pure chat | Force one durable file/note/patch |

## 5. Multi-agent / transfer failures

| Failure | Detection | Fix |
|---------|-----------|-----|
| Paste without files | Other AI “agrees” only | Transfer checklist fails |
| Vault loss | New AI lacks prior state | Explicit handoff block + files |
| Conflicting instructions | Project prompt fights AGENTS | AGENTS + skills win on Absolute Max triggers |

## 6. Safety / device (when tools allow)

| Failure | Detection | Fix |
|---------|-----------|-----|
| Destructive shell | Script not shown first | Plan → show → approve → run |
| Secret echo | Keys in output | Redact; never log full credentials |

## 7. Recovery order

1. State tier (T0–T3) and fidelity (FULL/PARTIAL)  
2. Re-verify skills list + one tool call  
3. Narrow to one module (e.g. STAIR only)  
4. Ship compounding asset even if research incomplete  
5. Never pretend full Arkon when T0  

## 8. Pre-flight (every substantial session)

```text
[ ] Version = v3.6 (or current package)
[ ] Skills present
[ ] Tier declared
[ ] Canonical user goal restated in one line
[ ] Success criteria visible
```
