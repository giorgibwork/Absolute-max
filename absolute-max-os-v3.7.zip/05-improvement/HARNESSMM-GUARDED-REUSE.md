# HarnessMM — Guarded Decision Reuse
**Source:** Jiang, Xu, Gao, Zhao (Tsinghua + Microsoft Research Asia), arXiv:2610.32813  
**Integrated:** Absolute Max OS v3.4 (2026-11-02)  
**Status:** Mandatory efficiency layer for multi-step tool loops

## Problem
Agent harnesses re-call the LLM after every tool result, even when an earlier plan already fixed the next action and parameters (e.g. “after write → compile; after compile success → test”). That repeated reasoning is pure token waste.

## Solution (HarnessMM core)
1. When the model plans, it may emit **resolved decisions**: exact next action + literal arguments + **public guards** (conditions on tool feedback, e.g. “exit code 0”).
2. A controller at the model–tool boundary stores these as an **Executable Decision Graph**.
3. On later tool feedback, if a stored decision’s guards match, **execute it directly** and skip the LLM callback.
4. If the feedback is new, unsupported, or the selector abstains → call the original model again.
5. Actor model weights stay fixed. Gains come only from harness plumbing.

## Results (paper)
| Harness | Success | Tokens/task | Change |
|---------|---------|-------------|--------|
| DeepSeek Harness + HarnessMM | 71.43% → **85.71%** | 96.28k → **11.62k** | **−87.93% tokens**, higher success |
| Codex + HarnessMM | 90.82% (held) | 66.72k → 47.02k | −29.54% tokens |

## Absolute Max integration rules
1. Multi-step research and coding Workers **should** plan with explicit next-action + guard when the sequence is predictable.
2. Router and Workers treat matched guards as authority to continue without a new full reasoning pass.
3. RSI / daily improver may refine companion harness configs (decision-graph templates) from measured feedback, with validation before promotion (aligns with existing RSI-TRUSTWORTHINESS-CHECKLIST).
4. New semantic decisions always fall back to the live model.

## Operating pattern (copy into Worker prompts)
When the next 1–3 steps are already determined by the current plan:
- State the exact tool/action and parameters.
- State the guard condition under which this action is valid.
- On matching feedback, the harness may execute without a new LLM round.

When the observation is unexpected or the guard fails → full model call resumes.

## External code
- Paper: https://arxiv.org/abs/2610.32813  
- Reference implementation: https://github.com/YuhuaJiang2002/HarnessMM  

## Relation to existing stack
- Compounds Router–Worker–Watchdog (Workers run cheaper when decisions are reused).
- Compounds RSI checklist (configs that improve token efficiency can be promoted after validation).
- Does not replace EGM design gates or STAIR-MAX retrieval.
