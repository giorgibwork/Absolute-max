# Absolute Max Stack Architecture — Compound Only
**Updated:** 2026-11-02 (v3.4)

```
MRIP
  └── Action-first shaping
        └── Absolute Max OS (orchestrator)
              ├── Eye of God
              ├── Arkon-Hyperresearch (+ Router/Worker/Watchdog)
              ├── STAIR-MAX
              ├── EGM Design Gate
              ├── HarnessMM Guarded Decision Reuse
              └── 05-improvement/*
```

## Routing
1. Hierarchical corpus → STAIR-MAX first
2. Research / deep / audit → Arkon-Hyperresearch
3. Optimize / best free → Eye of God
4. Non-trivial design → EGM first
5. Multi-task / long-horizon → Router assigns Workers; Watchdog monitors
6. Multi-step tool loops → HarnessMM reuses resolved decisions when guards match
7. Otherwise → Absolute Max core + MRIP
