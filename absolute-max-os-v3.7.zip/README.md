# Absolute Max OS v3.7

Maximal portable OS for **Grok**, **Gemini Work**, **Claude**, and **Arena Agent Mode**.

## Start here
1. `00-LOAD-ME-FIRST.txt`
2. `04-docs/HOW-TO-INSTALL-PRIMARY-HOSTS.md`
3. `04-docs/BEST-HOST-IMPLEMENTATIONS.md`
4. `03-transfer/HOST-POINTERS.md`
5. `05-improvement/FIDELITY-MATRIX.md`

## What is in v3.7
- Primary-host installs (Grok, Gemini, Claude, Arena)
- BEST-HOST-IMPLEMENTATIONS (Eye-of-God ranked)
- HOST-POINTERS (copy-paste)
- Fidelity matrix + anti-failure + verification layers
- ZHA watchlist (no fake speedups)
- Skills + tools + tier system (T0–T3)

## Tiers
T0 skills only · T1 live search/fetch · T2 + shell · T3 + memory/schedules  
Hyperresearch needs ≥ T1.
