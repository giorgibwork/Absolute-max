---
name: arkon-hyperresearch
description: Highest-rigor multi-phase deep research pipeline with Arkon Vault continuity and full 2026 stack (modules 1–27: RSPM, TAME, formal gates, Recuris EM–WM, Plugin library, RSI, Router-Worker-Watchdog, HarnessMM hooks, hard citation). Optimized for Arena.ai Agent Mode. Triggers: arkon-hyperresearch, hyperresearch with vault, deep research with arkon, maximum research quality with continuity, Arena agent research, router worker.
---

# Arkon Hyperresearch — Research Engine (Single Source of Truth) v3.4

**Role:** The only full research engine. Absolute Max routes research goals here.

## Core Rules

- Canonical query is gospel.
- Prefer free/open sources.
- Every major claim requires verified source support.
- Parallelize tool calls.
- Write durable artifacts to workspace (`research/runs/<tag>/`).
- No report ships without hard citation + hallucination gate + **Tether withdrawal** (no stale upstream-failing verdict served as proven).
- Every major claim requires verified source support with origin binding (raw span + schema + writer session). Evidence state is three-valued: proven / unproven / failed. Agent-own-report alone is never proven (PCM principle).
- Dependency tethers are written at the moment a verdict is formed; at read time any verdict whose support has failed anywhere in the store is withdrawn as unsettled and must be re-verified.
- Self-evolution patches require RSI Trustworthiness Checklist before promotion.
- Hierarchical corpora: run STAIR-MAX first; research only on retrieved spans.
- Multi-step tool sequences: use HarnessMM guarded decision reuse when the next action is already fixed.

## Modules 1–27 (full+ always on)

1–21. (Canonical research stack: TTME, TAME, disagreement, replication, self-consistency, paraphrastic, adversarial contracts, graph expertise, self-distillation, PAPER2LLM++, boundary/order memory, effort controller, formal gate, density clustering, self-questioning, few-shot judgment, structure-aware hygiene, RSPM sleep, hard citation, MCP/connector memory)

22. **Recuris EM–WM** — Working Memory conditions skill selection; four-way blame; validation-gated patches  
23. **TAME memory loop + Dependency Tether** — Executor applies, Evaluator scores contribution + trust; write-time dependency capture, read-time withdrawal of upstream-failing verdicts (arXiv:2610.25123).  
24. **Plugin library + RSI gate** — atomized mechanisms; checklist before promotion  
25. **Router** — global entry, assignment, single outward voice; no heavy tool execution  
26. **Worker isolation** — one focused task per isolated context; report only to Router  
27. **Watchdog** — progress monitor on long Workers; surface stalls in plain language  

## HarnessMM (efficiency)

When a Worker plan already fixes the next 1–3 actions with public guards (e.g. “compile success → run tests”), the harness may execute matched decisions without a new LLM callback. New or unsupported observations fall back to the live model. Actor weights stay fixed. See `05-improvement/HARNESSMM-GUARDED-REUSE.md`.

## Process (Arena)

Phase 0 Setup → 1 Decompose → 2 Width Sweep → 3 Contradiction + Replication → 4 Loci → 5 Evidence Digest → 6–7 Multi-Angle + Synthesis → 8 Critics + Typed Contracts → 9 Gap + Paraphrastic → 10 Self-Questioning + Cite-Check + Formal Gate → 11 Patch + TTME → 11.5 Sleep (RSPM + Recuris) → 12 Self-Evolution Hook (RSI required) → Hard Citation Gate → Final Report + Handoff.

Long-horizon: Router opens Worker tickets; Watchdog samples open tickets; HarnessMM reduces redundant callbacks inside Workers.

## Composition

- Absolute Max **routes** here; it does not re-implement the pipeline.
- Eye of God may supply free-ranked candidates as inputs.
- STAIR-MAX is mandatory before deep research on hierarchical docs.
- EGM is mandatory before implementing non-trivial stack mutations discovered during research.

## Absolute Rules

- Modules 1–27 active by default on full tier.
- No report without hard citation gate.
- No self-evolution promotion without RSI checklist.
- Every full run leaves research artifacts + improved memory/procedure cards.


## Runtime fidelity (v3.6)
- Full Arkon multi-source research requires **T1**: live web search or fetch with transcript.
- Without T1: label output **parametric-only**; do not use hyperresearch completion badge.
- Hard citations: prefer tool-retrieved sources; parametric claims = unproven until fetched.
- Apply FIDELITY-MATRIX and VERIFICATION-LAYERS on final reports (L3 critic when high-stakes).
