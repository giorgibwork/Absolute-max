---
name: structure-aware-retrieval
description: STAIR-MAX structure-aware generative retrieval. Uses document Table of Contents as the index; constrained decoding over valid leaf titles / hierarchical addresses; Local–Bridge–Global routing; dual prompt-only vs trained mode. Triggers: STAIR, STAIR-MAX, structure-aware retrieval, ToC retrieval, section-title retrieval, zero-hallucination retriever, hierarchical RAG, BookRAG-style.
---

# STAIR-MAX — Structure-Aware Retrieval (v3.4 live)

Turn structured long documents into a generative index. Output must be a real section title or hierarchical address that exists in the ToC. Structural hallucination of non-existent sections is a failure.

## Core contract

1. Extract or induce a clean hierarchical ToC.
2. Map every leaf title to its text span.
3. Build a trie (or equivalent) over valid leaf titles / addresses.
4. Retrieval unit: hierarchical address preferred (`Chapter X > Section Y > Leaf Z`).
5. Decode only over valid titles (hard constraint when possible; post-check when not).

## Dual mode

| Mode | When | How |
|------|------|-----|
| Prompt-only | Default | Long-context model receives full ToC + query; emit only a valid leaf; validate against trie |
| Trained | LoRA/QLoRA available | Train (ToC, query) → leaf and passage → leaf; hard trie decode |

## Hierarchical routing (large ToCs)

1. **Local** — tightest leaf that answers the query  
2. **Bridge** — sibling/parent nodes when multi-hop evidence is needed  
3. **Global** — document-level aggregation only when required  

## Mandatory pipeline

Phase 0 Structure extraction → Phase 1 (optional) adaptation data → Phase 2 prompt or train → Phase 3 constrained inference → Phase 4 report R@1 / hallucination rate when evaluating.

## Integration

- **Arkon-Hyperresearch**: hierarchical corpus → STAIR-MAX first; only retrieved spans enter research Workers.
- **Absolute Max / Eye of God**: prefer STAIR-MAX over length-chunk + vector DB on structured documents.
- **ADHD**: first concrete action is extract ToC → build constraint set → retrieve.

## Activation

STAIR · STAIR-MAX · structure-aware · ToC retrieval · hierarchical RAG · zero-hallucination section lookup

Do not use for proven structureless corpora unless a ToC can be induced first.
