---
name: hyperresearch
description: Highest-performance multi-phase deep research pipeline. Canonical modules and process live in arkon-hyperresearch (24-module 2026 stack). This skill is the Arena-friendly entry point; on activation, execute the full Arkon-Hyperresearch pipeline. Triggers: hyperresearch, deep research, full research pipeline, 16-step research, adversarially audited report, maximum research quality, Arena agent research.
---

# Hyperresearch

**Single source of truth for modules and process:** arkon-hyperresearch skill (modules 1–24).

On activation, load and execute the full Arkon-Hyperresearch pipeline (Phases 0–12, Sleep 11.5, hard citation gate, Recuris EM–WM, TAME Evaluator, RSI checklist on self-evolution).

Do not maintain a competing module list. Absolute Max routes research goals here via Arkon-Hyperresearch. Eye of God does not own this pipeline.

Arena rules: heavy sandbox, parallel tools, durable artifacts under `research/runs/`, connectors when available, free/open sources preferred.
