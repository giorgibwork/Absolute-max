# How to Implement the Absolute Max Stack

## Critical distinction

| Method | Valid? |
|--------|--------|
| Paste “you are Absolute Max” only | **No** — prompt theater |
| Install skill **files** + AGENTS.md + verify | **Yes** |
| Upload skills to project knowledge + short system pointer | **Yes** |
| GPT-8K instructions **plus** knowledge files | **Yes** |

Full skill install procedure: **`HOW-TO-INSTALL-SKILLS.md`** (required reading).

---

## 1. Choose your platform

| Platform | Primary path |
|----------|----------------|
| Grok / this project | Copy `02-skills/*/SKILL.md` → `~/.grok/skills/<name>/` |
| Claude Projects | Upload skill files to project knowledge |
| ChatGPT Custom GPT | GPT-8K-INSTRUCTIONS.md + upload skills to knowledge |
| Gemini Gems | Attach skill files + short system pointer |
| Cursor / local agents | `.cursor/skills/<name>/SKILL.md` or project skills dir |
| DSH / dsh-Go | `$DSH_HOME/skills/*.md` |
| Hermes / OpenClaw | Runtime skills directory |

---

## 2. Load order (after files exist)

1. `AGENTS.md`
2. `02-skills/absolute-max/SKILL.md` (orchestrator)
3. `01-core/MRIP_v3.md`
4. Task skills: arkon-hyperresearch, structure-aware-retrieval, eye-of-god, i-have-adhd, …
5. `05-improvement/` protocols when design / multi-step / memory work runs

---

## 3. Activation phrases

`absolute max` · `maximize this` · `eye of god` · `hyperresearch` · `STAIR` · `structure-aware` · `egm` · `harnessmm` · `router worker`

---

## 4. Expected behavior (proof of install)

- ADHD action-first shape (until user says stop adhd mode)
- MRIP five-block ending on substantial responses
- STAIR-MAX on hierarchical documents
- HarnessMM: skip redundant LLM calls when tool step already guarded
- Implement-on-discovery (no backlog-only patches)
- ≥1 compounding asset per major turn

If the agent cannot name skill **files** or fail the checklist in HOW-TO-INSTALL-SKILLS.md, reinstall.

---

## 5. Multi-AI continuity

Use Arkon Vault (or equivalent) handoffs so work continues across different AIs without loss of state. Each AI still needs **its own** skill file install — do not assume chat paste transfers the OS.
