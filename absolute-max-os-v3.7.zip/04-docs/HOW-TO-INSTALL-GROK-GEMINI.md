# Install Absolute Max — Grok & Gemini

**Superseded by the full primary-hosts guide:**

→ **`HOW-TO-INSTALL-PRIMARY-HOSTS.md`**

That document covers:
- A) Grok
- B) Gemini Work / Gems
- C) Claude Projects
- D) Arena.ai Agent Mode

Use PRIMARY-HOSTS for all new installs.
