**PRIMARY HOSTS: Grok and Gemini Work.** DSH sections below are optional.

# How to Install Tools & Plugins for Full Absolute Max Capabilities

**Rule:** Skills without working tools are half an OS.  
Claiming “research is active” without a **live search/fetch path**, or “memory is active” without a **live memory store**, is **capability theater** — same failure mode as prompt-only skills.

Skills = behavior files.  
Tools/plugins = **executable** search, fetch, memory, MCP, shell, schedules.

This document is **required** together with `HOW-TO-INSTALL-SKILLS.md`.

---

## Capability tiers (what “full” means)

| Tier | Name | Must be true |
|------|------|----------------|
| **T0** | Skills only | Skill files installed + verified |
| **T1** | Research-capable | Live **web search** and/or **web fetch** tool succeeds once in a fresh session |
| **T2** | Agent-capable | T1 + **shell or code exec** (or harness equivalent) with approve-before-destructive |
| **T3** | Full Absolute Max | T2 + **memory MCP or vault** + optional schedule/jobs + HarnessMM-style guarded tool loops |

Do **not** label the install “full Absolute Max” below **T1**.  
Do **not** label “hyperresearch ready” without a verified search or multi-source fetch path.

---

## Minimum tool matrix (free-first)

| Capability | Acceptable free installs | Not acceptable |
|------------|--------------------------|----------------|
| **Web search** | Keyless DSH search plugin; DuckDuckGo/Bing-style provider; RustXNG on external host; OpenRouter-compatible agent with search tool; Grok/Claude/Gemini **native** web tool enabled | “I will search” with no tool call; DeepSeek official search if no key and user forbade it |
| **Web fetch** | HTTP fetch tool; `dsh-web-fetch-http`; browser/MCP fetch | Summarizing from memory only |
| **Shell / scripts** | Sandboxed bash (DSH `dsh-tool-bash`); Cursor/terminal; Grok bash | Claiming scripts ran with no transcript |
| **Memory** | MemTether MCP; official MCP memory; project files as vault | “I remember” with no store |
| **MCP bridge** | Runtime MCP client + ≥1 server connected | Listing MCP names only |
| **Schedules / jobs** | `dsh-schedule` / `dsh-jobs`; host cron; Grok Automations | “Daily improver” with no registered job |
| **Guarded reuse** | HarnessMM-style plan+guards in harness, or PTC workflow | Re-asking the model every tool step with no guard logic |

Catalog detail: `03-transfer/EXTERNAL-TOOLS-AND-PLUGINS.md`.

---

## Platform install procedures

### A) Grok (this environment / xAI agent)

1. **Native tools** — ensure web search, browse, code/bash are available to the agent in the product UI.  
2. **Automations** — register the Absolute Max Stack Improver (or equivalent) as a real scheduled task, not a note.  
3. **MCP / connectors** — connect only what the user authorized; verify with one successful tool call each.  
4. **Verify T1:**  
   `Run one live web search for "HarnessMM arXiv 2610.32813" and return the title + link from the tool result.`  
   Must show tool output, not parametric memory alone.

### B) Claude / Cursor / coding agents

1. Enable **web search / fetch** in the product or via MCP.  
2. Install MCP servers as needed, e.g.:
   - memory / sequential-thinking  
   - MemTether: `pip install memtether` then register MCP  
   - filesystem / git as appropriate  
3. **Verify:** tool names appear in the agent’s tool list; one search + one fetch succeed.

### C) ChatGPT Custom GPT

1. Actions / tools: configure browsing or OpenAPI actions if available.  
2. Knowledge files ≠ live search. For T1 you need browsing or an external action.  
3. If no browse: document tier as **T0 only** and do not claim full hyperresearch.

### D) DSH / dsh-Go

1. **Bundled (use, don’t reinstall blindly):**  
   `dsh-tool-bash`, `dsh-tool-web`, `dsh-schedule`, `dsh-jobs`, `dsh-workflow-ptc`, `dsh-mcp-client`  
2. **Search (critical):**  
   - Do **not** rely on DeepSeek search API without a key.  
   - Install a **keyless** search plugin from a trusted index (e.g. `https://dshopen.org/index.json`) **or**  
   - Point a custom provider at RustXNG / DDG-style endpoint on a host you control.  
3. **Plugin market:** Plugins → Discover → Add index source → paste trusted `index.json` → install only after reading risk.  
4. **Verify T1 on device:**  
   One `web_search` (or equivalent) tool call returns real results in the trajectory.  
5. **Verify T2:** one sandboxed bash health script shown, then run only after user approve.

### E) Hermes / OpenClaw / other harnesses

1. Install harness plugins for browser/search, shell, MCP.  
2. Wire free model endpoint (e.g. OpenRouter `:free`) **and** confirm tools are bound to that profile.  
3. **Verify** tool list + one search in a fresh session.

---

## Search backend options (ranked free / Absolute Max)

| Rank | Backend | Keys | Notes |
|------|---------|------|-------|
| 1 | Host **native** web tool (Grok/Claude/Gemini) | Product-dependent | Easiest T1 |
| 2 | **Keyless DSH/community search plugin** | None | Phone / DSH path |
| 3 | **RustXNG** on x86 host + DSH/MCP client | None | Strong metasearch; not arm64 binary today |
| 4 | Paid search APIs (Exa, Tavily, …) | Yes | Only if free path exhausted |
| ❌ | DeepSeek search with no key / forbidden account | — | Exclude when user said OpenRouter-only |

---

## Verification checklist (tools)

Complete after skills checklist:

```text
[ ] Tier declared: T0 / T1 / T2 / T3
[ ] Web search OR fetch: one successful tool transcript saved (query + result snippet)
[ ] Tool names listed from runtime (not invented)
[ ] If DSH: search provider is NOT deepseek-only without key
[ ] If MCP claimed: `list tools` / server list shows connected server
[ ] If memory claimed: write one item + read it back from the store
[ ] If schedule claimed: job id / automation id exists outside the chat
[ ] Destructive shell: approve-before-run still on
[ ] Agent refuses to say "full Absolute Max" if below T1
```

**Anti-theater tests (ask the agent):**

1. `What search tool will you call by exact name?`  
2. `Execute one live search and show the tool payload.`  
3. `If tools are unavailable, say tier T0 and stop claiming hyperresearch.`

Failure to produce a tool transcript = tools **not** installed.

---

## Order of operations (other AI / new workspace)

1. Install **skills** (`HOW-TO-INSTALL-SKILLS.md`) → pass skills checklist  
2. Install **tools/plugins** (this file) → pass tools checklist at ≥ T1  
3. Only then paste `PASTE-ME-MASTER` / `GPT-8K-INSTRUCTIONS`  
4. Record tier in the workspace (`CURRENT-BASELINE` or local notes)

---

## Maintainer note (stack improver)

When adding a capability that needs a tool:

1. Document install in this file + `EXTERNAL-TOOLS-AND-PLUGINS.md`  
2. Add a verification test (one concrete tool call)  
3. Bump OS version and ship zip  
4. Never ship “use search” as a prompt line without a backend path  

Skills change behavior. **Tools change what is possible.** Both are required for full Absolute Max.
