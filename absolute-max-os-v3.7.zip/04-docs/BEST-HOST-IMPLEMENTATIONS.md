# Best Host Implementations — Absolute Max OS v3.6
**Research date:** 2026-11-04  
**Method:** Eye of God (free / high effect size) + Arkon multi-source host docs  
**Primary targets:** Grok · Gemini · Claude · Arena Agent Mode

This file is the **authoritative** host playbook.  
`HOW-TO-INSTALL-PRIMARY-HOSTS.md` is the step checklist; **this file** is why and what to put where.

---

## Universal ranking (Eye of God)

| Rank | Practice | Effect | Cost |
|------|----------|--------|------|
| 1 | **Skills/rules as files** (knowledge / `.grok/skills` / uploads), not chat agreement | Stops prompt theater | Free |
| 2 | **Short standing instructions** + long facts in files | Instructions stick; facts stay updatable | Free |
| 3 | **Name files when querying** (`Using FIDELITY-MATRIX.md, …`) | Retrieval accuracy | Free |
| 4 | **T1 live search** before hyperresearch claims | Real multi-source | Free tier limits |
| 5 | **One job per project/Gem/workspace** | Consistency | Free |
| 6 | **Verify with list-files + one tool transcript** | Install proof | Free |
| 7 | Giant PASTE-ME as only install | Low reliability | Free but weak |

---

## 1) Grok / Grok Build (xAI)

### Best pattern
| Layer | Put here |
|-------|----------|
| Standing project rules | Root **`AGENTS.md`** (and nested `AGENTS.md` for monorepos) |
| Reusable procedures | **`.grok/skills/<name>/SKILL.md`** with YAML frontmatter |
| Global personal defaults | `~/.grok/` rules / skills |
| One-shot extras | `grok --rules "..."` when using CLI |

**Discovery order (Grok Build):** `~/.grok/` → walk repo to cwd; reads `AGENTS.md` / `Agents.md` / `AGENT.md` / `CLAUDE.md` + `.grok/rules/*.md`. Deeper wins on conflict. Skills from `.grok/skills/`, `~/.grok/skills/`, plugins.

### Skill best practices (official-style)
1. Specific **description** (drives auto-invoke)  
2. Concrete ordered steps  
3. Name tools the skill needs  
4. One skill per workflow  
5. Commit project skills to git  

### Absolute Max mapping
```text
Repo root:
  AGENTS.md                    ← copy from package root AGENTS.md (keep short+hard rules)
  .grok/skills/absolute-max/SKILL.md
  .grok/skills/arkon-hyperresearch/SKILL.md
  ... (all six)
  docs or artifacts/05-improvement/  ← FIDELITY, ANTI-FAILURE, protocols
```

### Grok chat (non-Build)
- Custom instructions: short Absolute Max pointer only (character limits fluctuate historically; don’t dump full PASTE-ME).  
- Prefer project/workspace file upload where available.  
- Enable web/browse/code tools for T1+.

### Verify
`List skills under .grok/skills` · trigger `absolute max` · one web search transcript.

---

## 2) Claude Projects

### Best pattern (Anthropic-aligned community consensus 2026)
| Layer | Put here |
|-------|----------|
| **How** Claude works | **Project instructions** (short) |
| **What** the facts are | **Project knowledge** files |
| Cross-project procedures | Claude Skills (if available on plan) |
| This turn only | User message |

**Do not** paste the whole OS into project instructions.  
**Do** upload skill files + protocols to knowledge; instructions only point at them.

### Instruction template (copy)
```text
You are Absolute Max OS for this project.
Source of truth: project knowledge files (skills + AGENTS.md + FIDELITY-MATRIX.md).
Orchestrator: absolute-max. Triggers: absolute max, hyperresearch, STAIR, eye of god, egm, harnessmm.
Rules:
- Cite the knowledge file name for stack rules and for factual claims drawn from files.
- If a fact is not in knowledge or my message, say so — do not guess.
- Declare tier T0–T3. Hyperresearch only with live web tools (T1+).
- No ZHA speedup claims; no guaranteed HarnessMM paper token % on this host.
- Substantial turns: compounding asset + MRIP-style close when Absolute Max is active.
```

### Knowledge upload set (minimum)
1. `absolute-max.md` / `SKILL.md`  
2. `arkon-hyperresearch` · `eye-of-god` · `structure-aware-retrieval` · `i-have-adhd` · `hyperresearch`  
3. `AGENTS.md` · `MRIP_v3.md`  
4. `FIDELITY-MATRIX.md` · `ANTI-FAILURE-PLAYBOOK.md`  
5. STAIR-MAX · EGM · HARNESSMM · VERIFICATION-LAYERS  

**Naming:** descriptive filenames (`FIDELITY-MATRIX.md` not `doc1.md`).  
**Query style:** `Using STAIR-MAX.md and the uploaded manual, …`  
**Paid plans:** RAG expands project knowledge ~10× near context limits — still prefer fewer, better files.

### Verify
`List project knowledge files related to Absolute Max` · quote absolute-max frontmatter · one web-backed answer if tools on.

---

## 3) Gemini (Gems → Skills transition)

### Situation (2026)
- **Gems** still used on many accounts; **Skills** rolling out (personal Gems → skills from ~17 Nov 2026 on consumer; Workspace later).  
- Prefer patterns that work for **both**: short instructions + attachable reference files / SKILL.md packs.

### Best Gem / Skill structure (PTCF)
1. **Persona** — Absolute Max orchestrator  
2. **Task** — research / maximize / implement under fidelity rules  
3. **Context** — attached knowledge / skill files  
4. **Format** — action-first, MRIP close, tier declaration  

### Instruction template (copy)
```text
Persona: Absolute Max OS orchestrator (compose eye-of-god, arkon-hyperresearch, STAIR, EGM, HarnessMM-style guards).
Task: On triggers absolute max / hyperresearch / STAIR / maximize, follow attached Absolute Max files.
Context: Use only attached knowledge/skill files for stack rules. Prefer Grounding/Search for live facts.
Format: Action-first; declare T0–T3; cite file names; compounding asset on big turns.
Constraints:
- No guessing stack rules not in files.
- No hyperresearch without search/grounding.
- No ZHA speedups; no fake HarnessMM %.
If information is missing: say [MISSING: …] instead of inventing.
```

### Knowledge / Skill files
- Upload core skill markdown (convert docx/xlsx to **md/pdf/txt** if Skills reject Office formats).  
- Keep ≤ platform file caps (Gems historically ~10 files — prioritize the six skills + AGENTS + FIDELITY).  
- After Gem→Skill migration: package as SKILL.md-style skill where the product allows.

### Verify
Restate instructions · list attached files · one grounded search.

---

## 4) Arena.ai Agent Mode

### Best pattern
| Layer | Put here |
|-------|----------|
| Stack body | **Upload `.md` skills** each session/workspace as needed |
| Activation | **First message** Absolute Max block (see PRIMARY-HOSTS) |
| Tools | Built-in **web search + bash/sandbox** (T1/T2) |
| External apps | **Connectors** toggled **per turn** only when needed |
| Outputs | **Workspace** files (compounding assets) |

### Upload limits (Agent Mode, help center)
- ~25 MB/file, ~10 MB/PDF, ~50 MB total per turn  
- Types include `.md`, `.txt`, `.pdf`, code, images, csv, json, …

### Connector discipline
- Connect OAuth once; **enable only for the turn** that needs GitHub/Linear/Drive/…  
- Lean tool definitions → better tool choice  
- GitHub: sandbox copy of repo; PR workflow — push before merging session-ending PRs  

### First-run prompt (max effect)
```text
absolute max — list every uploaded Absolute Max filename,
declare tier from tools available this turn (search/bash/connectors),
web-search "HarnessMM arXiv 2610.32813",
write Workspace/absolute-max-health.md with skills, tier, fidelity notes.
```

### Fidelity on Arena
Strongest **tool** host among the four for free agentic loops. Still PARTIAL on true HarnessMM callback substitution; FULL on STAIR/EGM/MRIP/search-backed Arkon when search runs.

### Verify
Upload list in output · search in trajectory · Workspace health file · no WATCH claims as FULL.

---

## 5) Cross-host copy pack

### Minimum file set (all hosts)
```
AGENTS.md
02-skills/absolute-max (SKILL.md or .md)
02-skills/arkon-hyperresearch
02-skills/eye-of-god
02-skills/structure-aware-retrieval
02-skills/i-have-adhd
02-skills/hyperresearch
05-improvement/FIDELITY-MATRIX.md
05-improvement/ANTI-FAILURE-PLAYBOOK.md
```

### Optional high-value
STAIR-MAX · EGM · HARNESSMM · VERIFICATION-LAYERS · MRIP_v3 · PASTE-ME-MASTER (after files)

### Anti-patterns (all hosts)
| Don’t | Do |
|-------|-----|
| Instructions-only mega paste | Files + short pointer |
| Vague “be maximal” | Triggers + tier + fidelity bans |
| All connectors always on | Per-turn enable |
| Claim install without file list | Verify checklist |
| Hyperresearch offline | T0 + parametric label |

---

## 6) Suggested order of rollout (effect size)

1. **Arena Agent Mode** or **Grok Build** — best tool loops for Absolute Max  
2. **Claude Project** — best knowledge discipline (instructions vs files)  
3. **Gemini Gem/Skill** — good everyday; watch Skills migration  
4. Chat-only Grok/Claude/Gemini without files — T0 only  

---

## Sources (representative)
- Claude Projects / knowledge / instructions (Anthropic help + 2026 guides)  
- Gemini Gems PTCF + Skills migration notes (2026)  
- Arena Agent Mode help (uploads, workspace, connectors)  
- Grok Build skills + AGENTS.md discovery (xAI docs / community)  

Claims about host UI limits change; if a step fails, fall back to: **upload markdown skills + short pointer + T1 search + verify list**.
