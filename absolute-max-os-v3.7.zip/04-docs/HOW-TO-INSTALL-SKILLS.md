# How to Install Absolute Max Skills (Real Install, Not Prompt Theater)

**Rule:** Saying “Absolute Max is active” in chat is **not** an install.  
Skills must exist as **loadable files** (or platform project knowledge / custom instructions backed by those files). If the host can delete the chat and still has the skill files, the install is real.

---

## Package layout (from this zip)

```
02-skills/
  absolute-max/SKILL.md          ← preferred form (Grok / Cursor / agents)
  absolute-max.md                ← flat copy of the same content
  arkon-hyperresearch/SKILL.md
  arkon-hyperresearch.md
  eye-of-god/SKILL.md
  eye-of-god.md
  hyperresearch/SKILL.md
  hyperresearch.md
  i-have-adhd/SKILL.md
  i-have-adhd.md
  structure-aware-retrieval/SKILL.md
  structure-aware-retrieval.md
  structure-aware-retrieval-assets/   ← optional STAIR helpers
```

Each `SKILL.md` starts with YAML frontmatter (`name`, `description`, triggers). Do not strip frontmatter.

**Minimum set for full OS:** all six skills + `01-core/MRIP_v3.md` + root `AGENTS.md`.

---

## Platform install procedures

### A) Grok (xAI) / this project environment

1. Unzip the archive.
2. Copy each skill directory into the skills root:

```bash
# Adjust TARGET to your Grok skills path
TARGET="${HOME}/.grok/skills"   # or /home/workdir/.grok/skills in this project

for s in absolute-max arkon-hyperresearch eye-of-god hyperresearch i-have-adhd structure-aware-retrieval; do
  mkdir -p "$TARGET/$s"
  cp -f "02-skills/$s/SKILL.md" "$TARGET/$s/SKILL.md"
done
```

3. Copy protocols you want always available:

```bash
cp AGENTS.md "$TARGET/../" 2>/dev/null || true
# Keep 05-improvement/*.md in project artifacts or agent-readable folder
```

4. **Verify:** new chat → ask:  
   `List installed Absolute Max skills by name and one trigger each.`  
   Expected: six names matching the directories above.  
   Then: `absolute max` — behavior must shift (action-first, MRIP blocks).

5. **Fail condition:** agent only repeats paste text and cannot list skill **files** or paths → install incomplete.

---

### B) Claude Projects / Claude with project knowledge

1. Create or open a Project.
2. **Project knowledge → Upload files** (not only chat paste):
   - Upload every `02-skills/*/SKILL.md` (or the six flat `02-skills/*.md`)
   - Upload `AGENTS.md`, `01-core/MRIP_v3.md`, `01-core/STACK-ARCHITECTURE.md`
   - Upload `05-improvement/*.md` (at least EGM, STAIR-MAX, HARNESSMM, ROUTER-WORKER-WATCHDOG)
3. **Optional but recommended:** paste `03-transfer/PASTE-ME-MASTER.md` into Project instructions **after** files are uploaded.
4. **Verify:**  
   `Without using the chat history, list the Absolute Max skill files in project knowledge and quote the first line of absolute-max SKILL frontmatter.`  
   Must cite uploaded filenames.

---

### C) ChatGPT Custom GPT / Projects

**Hard limit:** Custom GPT instructions ≈ 8k characters.

1. **Instructions field:** paste entire `03-transfer/GPT-8K-INSTRUCTIONS.md` only.
2. **Knowledge / files:** upload the six skill files + `MRIP_v3.md` + `AGENTS.md` so the model can retrieve full text.
3. Do **not** rely on instructions alone for HarnessMM / STAIR / EGM detail — those live in the uploaded files.
4. **Verify:**  
   `Name the six Absolute Max skills from knowledge files (not from instructions alone).`  
   Failure to name files → knowledge not attached.

---

### D) Gemini Gems / Google AI Studio

1. Create Gem (or system instruction).
2. Attach / upload skill markdown files as knowledge.
3. Put a short pointer in system instruction:

```
You load Absolute Max OS from the attached skill files.
Primary orchestrator: absolute-max/SKILL.md (or absolute-max.md).
On trigger "absolute max" or "hyperresearch", follow those files and AGENTS.md.
Do not claim skills are loaded unless the attached files are present.
```

4. **Verify:** same file-name quiz as Claude.

---

### E) Cursor / VS Code agent / local coding agents

1. Place skills under a project folder the agent indexes, e.g.:

```text
.cursor/skills/absolute-max/SKILL.md
.cursor/skills/arkon-hyperresearch/SKILL.md
...
```

   or

```text
.agents/skills/<name>/SKILL.md
```

2. Point agent rules / AGENTS.md at that folder:

```text
Skills path: .cursor/skills/
Load Absolute Max OS: read AGENTS.md then 02-skills/*/SKILL.md
```

3. **Verify from terminal:**

```bash
ls .cursor/skills/*/SKILL.md
grep -l "name: absolute-max" .cursor/skills/*/SKILL.md
```

---

### F) DSH / dsh-Go / DeepSeek Harness

1. Copy skill markdown into `$DSH_HOME/skills/` (or profile skills dir):

```bash
mkdir -p "$DSH_HOME/skills"
cp 02-skills/*.md "$DSH_HOME/skills/"
# or directory form if your DSH skills loader expects folders
```

2. Set personal preferences / profile instructions to reference Absolute Max (short pointer only).
3. Prefer **Creator / PTC** presets for stack work; keep approve-before-run for device scripts.
4. **Verify:**  
   `ls $DSH_HOME/skills` shows the six files; agent can open `absolute-max.md` by path.

---

### G) OpenClaw / Hermes / other agent runtimes with skills folders

1. Map each `02-skills/<name>/SKILL.md` into the runtime’s skill directory (same names).
2. Register triggers from YAML `description` / frontmatter if the runtime uses a skill index.
3. **Verify** with a filesystem list + one activation phrase in a fresh session.

---

## Verification checklist (required after every install)

Copy and complete:

```text
[ ] Six skill files exist on disk or in project knowledge (list paths)
[ ] AGENTS.md is present and readable by the agent
[ ] MRIP_v3.md is present
[ ] Fresh session: agent lists six skill names without the install paste in context
[ ] Trigger "absolute max" produces action-first output + MRIP-style closing blocks
[ ] Trigger "STAIR" or "structure-aware" references ToC / hierarchical retrieval behavior
[ ] Agent does NOT claim "skills applied" without being able to cite file paths or knowledge item names
```

**Anti-theater rule:**  
If the only evidence of install is a chat message agreeing to act as Absolute Max, the install **failed**. Re-do file/knowledge steps.

---

## What “applied” must mean

| Claim | Acceptable evidence |
|-------|---------------------|
| Skill installed | Path to `SKILL.md` or knowledge attachment name |
| OS active | Triggers change behavior in a **new** session |
| Protocol active | Agent can summarize HarnessMM / EGM / STAIR from files |
| Transfer complete | Other AI can pass the verification checklist |

---

## After install: first commands

1. `absolute max` — confirm orchestrator  
2. `List Absolute Max modules and which skill file owns each`  
3. Optional: `Run health check of skill file presence`  

Then use research / maximize / STAIR as needed.

---

## Maintainer note (stack improver)

When adding a **new** skill to the OS:

1. Add `02-skills/<name>/SKILL.md` with frontmatter  
2. Add flat `02-skills/<name>.md` copy  
3. Register in root `AGENTS.md` load order / ownership table  
4. Add one row to this file’s minimum-set list if required for “full OS”  
5. Bump version, update `CURRENT-BASELINE.md`, ship new zip  
6. **Never** treat a prompt-only patch as shipping a skill  

---

## Next: tools (required for full capabilities)

After skills pass verification, install live tools:

→ **`HOW-TO-INSTALL-TOOLS-AND-PLUGINS.md`**

Research / hyperresearch claims need **tier T1+** (one successful search or fetch tool transcript). Skills without tools remain **T0**.
