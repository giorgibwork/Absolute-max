# Install Absolute Max — Primary Hosts
**Grok · Gemini Work · Claude · Arena Agent Mode**

Skills + tools + fidelity required. Prompt-only agreement = failed install.  
See also: `HOW-TO-INSTALL-SKILLS.md`, `HOW-TO-INSTALL-TOOLS-AND-PLUGINS.md`, `FIDELITY-MATRIX.md`.

**Deep best practices (Eye of God ranked):** `BEST-HOST-IMPLEMENTATIONS.md` — what goes in instructions vs files, Grok AGENTS.md discovery, Claude knowledge split, Gemini Gem→Skill transition, Arena upload limits & connectors.

---

## A) Grok (xAI)

### Skills
1. Unzip Absolute Max OS.  
2. Install skill files:

```bash
TARGET="$HOME/.grok/skills"   # or project .grok/skills
for s in absolute-max arkon-hyperresearch eye-of-god hyperresearch i-have-adhd structure-aware-retrieval; do
  mkdir -p "$TARGET/$s"
  cp -f "02-skills/$s/SKILL.md" "$TARGET/$s/SKILL.md"
done
```

3. Keep `AGENTS.md` and `05-improvement/` readable in the project.

### Tools (T1+)
- Enable **web search / browse / code**.  
- Verify with one live search (save transcript).  
- Optional: Automations for daily improver.

### Verify
- Fresh chat: list six skills by name.  
- `absolute max` changes behavior.  
- One search tool transcript.  
- Pass FIDELITY-MATRIX pre-flight.

---

## B) Gemini Work / Gems

### Skills
1. Create or open a Gem / Workspace.  
2. **Upload** to project knowledge (do not only paste):
   - All `02-skills/*/SKILL.md` (or flat `.md`)
   - `AGENTS.md`, `01-core/MRIP_v3.md`
   - `05-improvement/FIDELITY-MATRIX.md`, STAIR-MAX, HARNESSMM, EGM, ANTI-FAILURE-PLAYBOOK
3. System instruction (short pointer only):

```text
Absolute Max OS is loaded from attached skill files.
Orchestrator: absolute-max. On "absolute max" / "hyperresearch" / "STAIR", follow those files and AGENTS.md.
Declare tier T0–T3. No hyperresearch without live search/grounding.
Never claim ZHA speedups or HarnessMM paper % as guaranteed on this host.
Refuse "skills applied" without citing attached file names.
```

### Tools (T1+)
- Enable **Grounding with Google Search** (or equivalent).  
- Verify one grounded response with sources.

### Verify
- New session: name attached skill files.  
- Grounded search works.  
- FIDELITY-MATRIX honored.

---

## C) Claude (Projects / Claude.ai / API workspaces)

### Skills (real install)
1. Create or open a **Claude Project** (preferred over a one-off chat).  
2. **Project knowledge → Add files / upload**:
   - `02-skills/absolute-max/SKILL.md` (or `.md`)
   - `02-skills/arkon-hyperresearch/SKILL.md`
   - `02-skills/eye-of-god/SKILL.md`
   - `02-skills/hyperresearch/SKILL.md`
   - `02-skills/i-have-adhd/SKILL.md`
   - `02-skills/structure-aware-retrieval/SKILL.md`
   - `AGENTS.md`
   - `01-core/MRIP_v3.md`
   - `05-improvement/FIDELITY-MATRIX.md`
   - `05-improvement/ANTI-FAILURE-PLAYBOOK.md`
   - `05-improvement/STAIR-MAX.md`, `EGM-ELEPHANT-GOLDFISH.md`, `HARNESSMM-GUARDED-REUSE.md`, `VERIFICATION-LAYERS.md`
3. **Project instructions** (short pointer — full stack lives in files):

```text
You load Absolute Max OS v3.6 from project knowledge files.
Primary orchestrator: absolute-max skill. Follow AGENTS.md load order.
Triggers: absolute max, hyperresearch, STAIR, eye of god, egm, harnessmm.
Declare capability tier T0–T3. Hyperresearch requires live web tools (T1+).
Cite skill/knowledge file names when asked if the OS is installed.
Never claim ZHA attention speedups or guaranteed HarnessMM paper token % on this host.
Implement on discovery; leave compounding assets on substantial turns.
FIDELITY-MATRIX and ANTI-FAILURE-PLAYBOOK apply.
```

4. Optional long paste: `03-transfer/PASTE-ME-MASTER.md` **only after** files are uploaded.  
5. Custom GPT-style 8k limit does not apply; still prefer files over one giant paste.

### Tools (T1+)
- Enable **web search** / analysis tools available on your Claude plan.  
- Artifacts / code execution when present → supports T2.  
- Verify: one search or fetch with visible sources in a fresh project chat.

### Verify
```text
[ ] List Absolute Max skill files by name from project knowledge
[ ] Quote first line of absolute-max frontmatter without re-uploading
[ ] absolute max → action-first + MRIP-style close
[ ] One live search/tool transcript (T1)
[ ] Refuses ZHA speedup claims
```

### Claude-specific pitfalls
| Pitfall | Fix |
|---------|-----|
| Only Project Instructions, no knowledge files | Upload skills — instructions alone = T0 theater risk |
| Files uploaded once then ignored | Ask agent to list knowledge filenames each major session |
| Web disabled | Stay T0; no hyperresearch badge |
| Long PASTE-ME without files | Files first, paste second |

---

## D) Arena.ai Agent Mode

Arena Agent Mode autonomously plans multi-step work with **built-in tools** (web search, bash/sandbox, file write, image gen) and optional **Connectors** (GitHub, Linear, Gmail, Drive, etc.).

Absolute Max is optimized for this mode: action-first, tool loops, HarnessMM-style guards, STAIR, research.

### Skills / instructions
Arena does not use a `.grok/skills` folder. Install via **files + session instructions**:

1. Unzip Absolute Max OS.  
2. **Upload** to the Agent Mode session / workspace (supported: `.md`, `.txt`, `.pdf`, code, etc.):
   - Prefer uploading the whole `02-skills/` set (or a single zip of markdown if the UI allows, then ask agent to unpack listing)
   - Minimum: `AGENTS.md` + six skill markdown files + `FIDELITY-MATRIX.md` + `ANTI-FAILURE-PLAYBOOK.md`
3. Put this in the **first user message** or pinned instruction (not instead of files):

```text
ABSOLUTE MAX OS v3.6 — Arena Agent Mode

Load and obey the uploaded Absolute Max skill files and AGENTS.md.
You are the Absolute Max orchestrator (absolute-max skill).
On triggers absolute max / hyperresearch / STAIR / eye of god / egm / harnessmm:
follow those modules with FULL/PARTIAL fidelity only (see FIDELITY-MATRIX).

Rules for Agent Mode:
1. Build a plan with explicit tool steps and guards (HarnessMM-style). When a guard matches tool output, continue without re-asking for the same decision.
2. Use web search for any non-parametric research (T1). No hyperresearch badge without search tool use.
3. Prefer free/public sources (Eye of God). Rank by effect size.
4. Hierarchical docs → STAIR-MAX (ToC → real section leaves only).
5. Non-trivial design → EGM (Elephant draft + Goldfish zero-context critique) before implement.
6. End substantial work with MRIP-style blocks + ≥1 compounding asset in the Workspace.
7. Never claim ZHA attention speedups or guaranteed HarnessMM paper token % on Arena.
8. Declare tier T0–T3 at start of complex jobs.
9. Connectors: only use services the user enabled for this turn.

First action: list uploaded Absolute Max files by name, then confirm tier from available tools (search/bash/connectors).
```

4. Optional: also paste a shortened core from `03-transfer/GPT-8K-INSTRUCTIONS.md` if the session has no durable project knowledge — **still upload files**.

### Tools (Arena-native → map to tiers)

| Arena capability | Tier impact |
|------------------|-------------|
| Web search | T1 |
| Bash / sandbox | T2 |
| File write / Workspace | Compounding assets |
| GitHub connector (clone, commit, PR) | T2+ repo workflows |
| Linear / Notion / Drive / Gmail / … | Domain T3 when enabled |
| Image generation | Optional; not required for research OS |

**Turn-level connector toggles:** only enable connectors needed for the task (keeps tool list lean).

### Recommended first Arena run
```text
absolute max — confirm OS from uploaded files, list tools available this turn,
run one web search for "HarnessMM arXiv 2610.32813", then write
Workspace/absolute-max-health.md with: skills seen, tier, fidelity notes.
```

### Verify (Arena)

```text
[ ] Uploaded files listed by name in agent output
[ ] Web search used at least once (trajectory / tool trace)
[ ] Plan shows steps + guards for multi-step work
[ ] Workspace contains at least one compounding file after a big task
[ ] No ZHA speedup claims
[ ] GitHub/other connectors used only when toggled on
```

### Arena-specific pitfalls
| Pitfall | Fix |
|---------|-----|
| Instruction paste only, no uploads | Upload markdown skills every new workspace if not persistent |
| All connectors on every turn | Enable only what the task needs |
| Assuming repo write without GitHub connected | Connect + toggle GitHub; work in sandbox first |
| Treating Agent Mode as chat-only | Force plan → tools → Workspace asset |

### Fidelity on Arena
- **FULL:** STAIR, EGM, MRIP, Eye of God ranking, ADHD shape, Tether/PCM discipline  
- **PARTIAL:** HarnessMM (plan+guards; Arena still controls callback policy)  
- **WATCH:** ZHA  
- Arkon-Hyperresearch: **FULL only when web search runs**; else parametric-only  

---

## All four hosts — shared success criteria

| Check | Pass |
|-------|------|
| Skill files present | Paths, project knowledge names, or Arena upload list |
| Tier | T1+ for research claims |
| Fidelity | No WATCH claims as FULL |
| Compounding | ≥1 durable asset on big turns |
| Degraded honesty | T0 stated when tools missing |
| Anti-theater | Agent cites files/uploads, not “I applied Absolute Max” alone |

## Order of operations (any host)
1. Upload / install skill **files**  
2. Enable tools (search minimum for T1)  
3. Short system / first-message pointer  
4. Optional long PASTE-ME  
5. Run verify checklist + FIDELITY-MATRIX pre-flight  

---

## Research-backed refinements (2026-11-04)

### Claude
- **Instructions = how; knowledge = what.** Never put the full OS in instructions.
- Prompt with **filename**: `Using FIDELITY-MATRIX.md and absolute-max.md, …`
- Prefer **one Project = one job** (Absolute Max research OS as its own project).
- Paid: RAG expands knowledge near limits; still upload the minimum high-value set.

### Gemini
- Structure instructions as **Persona · Task · Context · Format** (PTCF).
- **Gems → Skills** migration on personal accounts from ~Nov 2026: keep markdown portable; convert Office knowledge to md/pdf/txt if needed.
- Cap knowledge to the highest-value files if the host limits count (~10 on classic Gems).

### Arena
- Respect **per-turn upload budgets** (~50 MB total / turn; md preferred).
- **Connectors opt-in per turn** — do not leave all enabled.
- Persist compounding outputs in **Workspace**; with GitHub, finish pushes before merging session PRs.

### Grok Build
- Root **AGENTS.md** + **`.grok/skills/*/SKILL.md`** is the gold path.
- Short specific AGENTS rules beat long essays; skills hold long procedures.
