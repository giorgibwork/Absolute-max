# External Tools & Plugins — Absolute Max OS v3.5

**Skills alone are not enough.** Install and **verify** tools per  
`04-docs/HOW-TO-INSTALL-TOOLS-AND-PLUGINS.md`.  
Prompt-only “I can search” without a tool transcript = failed capability install.

---

## Capability tiers (summary)

| Tier | Requirement |
|------|-------------|
| T0 | Skills files only |
| T1 | Live web search and/or fetch (verified once) |
| T2 | T1 + shell/code with approve-before-destructive |
| T3 | T2 + memory MCP/vault + schedules/jobs optional |

Full Absolute Max claims require **≥ T1**. Hyperresearch claims require a verified multi-source or live search path.

---

## Agent harnesses (runtimes)

| Tool | License | Why |
|------|---------|-----|
| DeepSeek Harness (`@deepseek-ai/dsh`) | MIT | Plugin architecture |
| dsh-Go (Android client) | Community | On-device / remote DSH |
| dsh-superagent-prototype | MIT | Router/Worker-style coding agent |
| google/elephant-goldfish-model | Apache 2.0 | EGM design gate pattern |
| Hermes Agent (Nous) | Open | Skills + tools + mobile client path |
| localharness / octop-harness | MIT | Local / production harness patterns |

---

## Web search & fetch (required for T1)

| Path | Keys | Notes |
|------|------|-------|
| Host native web tool (Grok, Claude, Gemini, …) | Product | Prefer when available |
| Keyless DSH community search plugin | None | Use plugin market index; not DeepSeek-account search |
| RustXNG (sahenjp/RustXNG) | None | Self-hosted metasearch; prebuilt **x86_64** (not arm64 phone binary) |
| `dsh-web-fetch-http` | None | Fetch only — not full search |
| `dsh-web-deepseek-api` | DeepSeek key | **Exclude** if user is OpenRouter-only / no DeepSeek account |

**DSH plugin indexes (trusted starting points):**
- `https://dshopen.org/index.json`
- `https://dshseek.com/market/dsh-index.json`
- `https://cdn.jsdelivr.net/npm/dsh-plugin-catalog/index.json`

Add via Plugins → Discover → Index sources. Install only after reading risk.

---

## DSH bundled tools (typical 0.2.1-rc.x)

Use when present — still **verify** with one call:

| Plugin | Role |
|--------|------|
| `dsh-tool-bash` | Sandboxed shell — phone/scripts |
| `dsh-tool-web` | Web surface (provider-dependent) |
| `dsh-schedule` | Durable reminders |
| `dsh-jobs` | Background jobs |
| `dsh-workflow-ptc` | Batch tool workflows / guarded steps |
| `dsh-mcp-client` | MCP bridge |
| `dsh-experimental-session-inspector` | Session log inspection |

---

## Memory & MCP

| Tool | Role |
|------|------|
| **MemTether** (`pip install memtether`) | Local SQLite MCP — hash chain, supersession, source attribution |
| tether-memory (PyPI) | Local MCP memory + FTS5 |
| Official MCP memory / sequential-thinking | Structured memory / steps |
| mcpsurfr (or equivalent) | Local search re-rank MCP |

**Verify memory:** write one record → new turn → read it back from the tool/store.

---

## Evidence protocols (prompt + discipline; pair with tools)

| Protocol | Source | Use |
|----------|--------|-----|
| Dependency-Tethered Memory | arXiv:2610.25123 | Withdraw failed upstream support |
| PCM | arXiv:2610.39109 | Proven / unproven / failed claims |
| HarnessMM | arXiv:2610.32813 | Guarded decision reuse (fewer LLM round-trips) |
| STAIR | arXiv:2609.03874 | ToC hierarchical retrieval |
| EGM | google/elephant-goldfish-model | Design gate |

---

## Free model endpoint (example)

| Field | Value |
|-------|--------|
| Base URL | `https://openrouter.ai/api/v1` |
| Free models | IDs ending in `:free` (e.g. `nvidia/nemotron-3.5-super-vl:free`) |
| Limits | Often 50 req/day free; **1000/day** after one-time ~$10 credit purchase |

Model endpoint ≠ search tool. Both must be configured for T1 research under free constraints.

---

## Adoption checklist (other AI)

1. Install skill **files** (`HOW-TO-INSTALL-SKILLS.md`)  
2. Install/enable tools (`HOW-TO-INSTALL-TOOLS-AND-PLUGINS.md`)  
3. Run **one live search** and keep the tool transcript  
4. Declare tier T0–T3 honestly  
5. Only then load PASTE-ME / GPT-8K paste layers  

---

## Token efficiency

HarnessMM (arXiv:2610.32813) — plan future tool steps + guards; on match, execute without a new LLM decision. Pair with PTC / workflow plugins where available.
