# AI Transfer Kit — Absolute Max OS v3.5

## Rule first

**Prompts alone are not a transfer.**  
Receiving AI must:

1. Install skill **files** → `04-docs/HOW-TO-INSTALL-SKILLS.md`
2. Install/enable **tools & plugins** → `04-docs/HOW-TO-INSTALL-TOOLS-AND-PLUGINS.md`
3. Pass both verification checklists (files + **one live search/fetch transcript**)
4. Declare tier T0–T3 honestly

“I applied Absolute Max” without file paths and tool evidence = failed transfer.

## Files

| File | Use case |
|------|----------|
| **GPT-8K-INSTRUCTIONS.md** | Custom GPT instructions (≤8k). Still upload skill files to Knowledge. |
| **PASTE-ME-MASTER.md** | Long-context paste — **after** skills + tools |
| **EXTERNAL-TOOLS-AND-PLUGINS.md** | Tool/plugin catalog + search backends |
| `../02-skills/*/SKILL.md` | **Required** skill bodies |
| `../AGENTS.md` | Master agent configuration |
| `../01-core/MRIP_v3.md` | Recursive improvement contract |

## Transfer steps (other AI)

1. Unzip Absolute Max OS package  
2. Follow **HOW-TO-INSTALL-SKILLS.md**  
3. Follow **HOW-TO-INSTALL-TOOLS-AND-PLUGINS.md** (get to ≥ T1)  
4. Paste GPT-8K or PASTE-ME-MASTER only after checklists pass  
5. Refuse to mark transfer complete until skill paths + tool transcript exist  

## Design

- GPT-8K keeps core under the character limit  
- Full modular skills remain source of truth for protocols  
- Tools make search/memory/shell real — not verbal  
- Improver must ship install paths for new tools, not only prompt lines  
